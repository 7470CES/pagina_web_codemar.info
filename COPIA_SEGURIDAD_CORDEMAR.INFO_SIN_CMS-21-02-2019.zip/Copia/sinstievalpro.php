﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>LA EVALUACIÓN ACADÉMICA</title>
	<link rel="stylesheet" href="css/estilossinstievalpro.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/evaluacion.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>LA EVALUACIÓN ACADÉMICA.</center></strong>
			<p>&nbsp;</p>
			Los principales objetivos de la evaluación académica son:
<p>&nbsp;</p>
•	Determinar la obtención de los objetivos específicos y objetivos generales periódicos propuestos en cada asignatura, por parte del alumno.
<p>&nbsp;</p>
•	Medir el avance de los alumnos en la adquisición de conocimientos.
<p>&nbsp;</p>
•	Determinar el afianzamiento de valores y principios inculcados en el colegio.
<p>&nbsp;</p>
•	Verificar la contribución de cada asignatura en la consolidación del perfil propuesto (la persona educada), para los alumnos graduandos.
<p>&nbsp;</p>
•	Identificar características personales, intereses, aptitudes, ritmos de desarrollo, y estilos de aprendizaje en los estudiantes.
<p>&nbsp;</p>
•	Identificar en el educando las dificultades que tiene para lograr los objetivos académicos propuestos en cada asignatura.
<p>&nbsp;</p>
•	Ofrecer al alumno oportunidades para aprender del acierto, del error y en general de las experiencias.
<p>&nbsp;</p>
•	Proporcionar al profesor información para re-orientar o continuar su práctica pedagógica.
<p>&nbsp;</p>

La evaluación es el proceso de comparación del estado de desarrollo formativo y cognoscitivo de un alumno, con relación a los objetivos específicos propuestos en el currículo.   Se puede realizar así:
<p>&nbsp;</p>
•	Mediante el uso de pruebas de comprensión, análisis, discusiones, crítica, apropiación de conceptos, y aplicación de conocimientos; que permitan apreciar el proceso de organización del conocimiento que ha elaborado el estudiante, y su capacidad para producir formas para solucionar problemas prácticos.
<p>&nbsp;</p>
•	Mediante apreciaciones cualitativas hechas como resultado de la observación, los diálogos, las entrevistas abiertas, formuladas por el profesor acerca de sus alumnos.
<p>&nbsp;</p>

La evaluación debe evaluar al alumno en forma integral, por lo tanto, debe tener en cuenta:
<p>&nbsp;</p>
•	El desarrollo cognoscitivo del alumno: Es decir el aspecto intelectual, el proceso de organización del conocimiento elaborado por el alumno, y las capacidades o competencias o habilidades demostradas en la solución de problemas y ejercicios prácticos.
<p>&nbsp;</p>
•	La adquisición de hábitos de estudio: Es decir la forma de realizar el trabajo escolar.  La valoración de su nivel de Disciplina o desempeño en el cumplimiento de sus funciones como estudiante.
<p>&nbsp;</p>
•	El desarrollo personal: Es decir los demás aspectos de la formación integral (Moral, Social, Intelectual, Afectivo y Físico), verificando si el alumno está logrando consolidar en su carácter el perfil propuesto por la institución.
<p>&nbsp;</p>

Calificación del desarrollo cognoscitivo del alumno:
Toda previa y examen periódico o trabajo académico será  calificado con números en una escala del 0.0 al 5.0.  Y tendrá una correspondiente valoración cualitativa de acuerdo a la siguiente tabla.
<p>&nbsp;</p>
			
			
	<center><table width="200" border="1">
  <tbody>
    <tr>
      <td>NUMEROS</td>
      <td>VALORACION</td>
		</tr>
    <tr>
      <td>De 0.00 a 2.99</td>
      <td>BAJO</td>
    </tr>
    <tr>
      <td>De 3.00 a 3.99</td>
      <td>BASICO</td>
    </tr>
    <tr>
      <td>De 4.00 a 4.49</td>
      <td>ALTO</td>
    </tr>
    <tr>
      <td>De 4.50 a 5.00</td>
      <td>SUPERIOR</td>
    </tr>
  </tbody>
			</table></center>
		
<p>&nbsp;</p>

Determinación de la calificación de una asignatura en un periodo académico:
Para determinar si un alumno alcanzó o no el objetivo general propuesto en una asignatura,    se procederá a computar las cinco calificaciones reglamentarias obtenidas en un periodo académico. Cuatro obtenidas de pruebas de conocimiento y trabajos académicos y una quinta obtenida de la valoración cualitativa que haga el profesor en los aspectos de desempeño: Puntualidad, Organización, Responsabilidad, Atención y Disposición.  El promedio es la calificación definitiva en dicho periodo y tendrá una valoración correspondiente, de acuerdo a la tabla anterior. 
<p>&nbsp;</p>

Determinación de la calificación de una asignatura en el año escolar:
Para determinar si un alumno alcanzó o no el objetivo general anual propuesto en una asignatura, se procederá a sumar el acumulado académico de dicha materia en cada periodo.   Teniendo en cuenta que dichos acumulados tienen el siguiente valor:
 <p>&nbsp;</p>
			
			<center><table width="200" border="1">
  <tbody>
    <tr>
      <td>PERIODO</td>
      <td>ACUMULADO</td>
    </tr>
    <tr>
      <td>Primero</td>
      <td>15%</td>
    </tr>
    <tr>
      <td>Segundo</td>
      <td>15%</td>
    </tr>
    <tr>
      <td>Tercero</td>
      <td>30%</td>
    </tr>
    <tr>
      <td>Cuarto</td>
      <td>40%</td>
    </tr>
  </tbody>
			</table></center>
<p>&nbsp;</p>

Calificación del desempeño escolar o disciplina del alumno:
La adquisición de hábitos escolares será calificada con números de porcentaje en una escala del 0% al 100%.  Teniendo en cuenta la apreciación cualitativa de todos los profesores en su materia o materias de los aspectos: Puntualidad, Organización, Responsabilidad, Atención, y Disposición.   Y tendrá una correspondiente valoración de acuerdo a la siguiente tabla:
<p>&nbsp;</p>
			
			<center><table width="200" border="1">
  <tbody>
    <tr>
      <td>NUMEROS</td>
      <td>VALORACIÓN</td>
    </tr>
    <tr>
      <td>De 0% a 69%</td>
      <td>BAJO</td>
    </tr>
    <tr>
      <td>De 70% a 79%</td>
      <td>BASICO</td>
    </tr>
    <tr>
      <td>De 80% a 89%</td>
      <td>ALTO</td>
    </tr>
	  <tr>
      <td>De 90% a 100% </td>
      <td>SUPERIOR</td>
    </tr>
  </tbody>
				</table></center>
			<p>&nbsp;</p>
Calificación del desarrollo personal del alumno:
El desarrollo personal del alumno será calificado con números de porcentaje en una escala del 0% al 100%.   Teniendo en cuenta las anotaciones en la hoja de Conducta del alumno y la apreciación cualitativa de el director de grupo y el líder de grupo.  En aspectos tales como: Aseo personal, trato social, compostura, colaboración, y toma de decisiones.  Y tendrá una correspondiente valoración de acuerdo a la siguiente tabla:
<p>&nbsp;</p>
			<center><table width="200" border="1">
  <tbody>
    <tr>
      <td>NUMEROS</td>
      <td>VALORACIÓN</td>
    </tr>
    <tr>
      <td>De 0.00 a 2.99</td>
      <td>BAJO</td>
    </tr>
    <tr>
      <td>De 3.00 a 3.99</td>
      <td>BASICO</td>
    </tr>
    <tr>
      <td>De 4.00 a 4.49</td>
      <td>ALTO</td>
    </tr>
    <tr>
      <td>De 4.50 a 5.00</td>
      <td>SUPERIOR</td>
    </tr>
  </tbody>
				</table></center>

<p>&nbsp;</p>


Causales de Reprobación Académica en un Grado:
<p>&nbsp;</p>
Un alumno reprueba su curso, cuando presente una o más de las siguientes condiciones:
<p>&nbsp;</p>
•	Haber alcanzado o superado el 10% de inasistencia injustificada a clases.  (20 días de inasistencia)<p>&nbsp;</p>
•	Haber obtenido un promedio general inferior a 3.0<p>&nbsp;</p>
•	Haber reprobado tres o más áreas<p>&nbsp;</p>
•	Haber sido convocado y autorizado a presentar actividades de nivelación y no hacerlo en el tiempo perentorio. <p>&nbsp;</p>
•	Haber presentado actividades de nivelación y seguir presentando las mismas deficiencias que mantengan la reprobación de las áreas en cuestión.<p>&nbsp;</p>





		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

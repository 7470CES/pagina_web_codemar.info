﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ASOCIACIÓN DE PADRES DE FAMILIA</title>
	<link rel="stylesheet" href="css/estiloshistory.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<h1><strong><center>ASOCIACIÓN DE PADRES DE FAMILIA</center></strong></h1>
			<p>&nbsp;</p>
		A esta Asociación pertenecen todos los acudientes y Padres de Familia del Colegio.  Este estamento está representado por La Junta de Padres de Familia y por el Consejo de Padres.
	    </article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Biblioteca</title>
	<link rel="stylesheet" href="css/estiloshistory.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<h1><strong><center>BIBLIOTECA</center></strong></h1>
			<p>&nbsp;</p>
			Se espera que los niños se relacionen desde temprana edad con el conocimiento,  se interesen por la lectura, y bajo la dirección de sus profesores exploren diferentes temas que complementen lo desarrollado en clase.    Son los profesores quienes inician a nuestros niños en la lectura,  al principio interesándolos y sembrando en ellos la curiosidad de saber aquellos detalles que los asombran,  posteriormente,  haciendo uso de libros y demás recursos multimedia disponibles para realizar trabajos intelectuales.    Es en esta actividad donde aprenden a hacer resúmenes,  investigaciones secundarias,  manejar información e identificar aquella relevante según el caso, que satisface el requerimiento académico que sirve de complemento a las clases,  que refuerza o amplía los temas tratados.   
<p>&nbsp;</p>
La asidua asistencia de los alumnos a la Biblioteca,  hace de ellos personas educadas que se relacionan con los libros y se acostumbran a investigar,   a aprender y a desaprender, a actualizarse y a desarrollar la habilidad de aprender por sí mismos.
<p>&nbsp;</p>
El horario de biblioteca es  de 8:30 AM  a  12:00M  y de 3:15 PM  a  5:30 PM.  De lunes a viernes.   En la mañana la visita a la biblioteca se hace con la compañía de profesores que dirigen la actividad a realizar, según lo planeado en la asignatura o cátedra que regentan;   y en la tarde los alumnos lo deben hacer por iniciativa propia para realizar sus propias actividades de investigación o afianzamiento.

	
		</article>
		</section>
		<hr style="color: white" />
		<footer><center>COLEGIO EL CORAZÓN DE MARÍA<br>
Carrera 18 No. 15-59 Agustin Codazzi - Cesar-Colombia - Tel.: 5767353 - 3153295086<br>
E-mail: colegioelcorazondemaria@cordemar.org
			<p>&nbsp;</p></center>
			</footer>
</body>
</html>

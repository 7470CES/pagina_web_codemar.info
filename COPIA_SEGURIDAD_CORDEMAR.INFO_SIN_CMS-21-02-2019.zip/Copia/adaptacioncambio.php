﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Impulsamos la adaptación al cambio y el aprendizaje continuo</title>
	<link rel="stylesheet" href="css/estilosespiritufam.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<strong><center>Impulsamos la adaptación al cambio y el aprendizaje continuo

</center></strong>
			<p>&nbsp;</p>
			Vivimos en una sociedad sacudida por cambios rápidos que afectan a todos los ámbitos de la vida.<p>&nbsp;</p>
La educación marianista, desde sus mismos orígenes, encara el futuro con valentía, serenidad y
apertura de miras, haciendo que los cambios se vivan como oportunidades de crecimiento y mejora.
<p>&nbsp;</p>
La adaptación al cambio es una llamada a renovarse permanentemente y a vivir abiertos a las posibilidades de futuro que el presente nos brinda.
<p>&nbsp;</p>
Formamos a nuestros alumnos para que comprendan el mundo cambiante que les toca vivir y
les enseñamos a discernir con prudencia y a elegir de forma responsable.
<p>&nbsp;</p>
Los educadores estamos abiertos a nuevas metodologías e investigamos nuevas estrategias de
aprendizaje, manteniendo un equilibrio entre la afirmación de lo que sigue siendo válido y la
disposición a renovarse continuamente.
<p>&nbsp;</p>
De manera especial potenciamos el buen uso de las tecnologías de la información y la comunicación, motivando al alumno y ayudándole a desarrollar una competencia digital que le
capacite para incorporar estas tecnologías a su bagaje personal.    Pero sobre todo, trabajamos
para construir en el alumno criterios fundamentados que le permitan discernir, con espíritu
crítico, qué información es la pertinente de entre todas las disponibles, tomando decisiones
adecuadas sobre su propio aprendizaje.
<p>&nbsp;</p>
De todo ello se concluye la necesidad de que las personas estén en disposición de aprender
de manera permanente a lo largo de toda la vida. Y es nuestra intervención educativa la que
motiva, impulsa y orienta esta actitud de búsqueda y elaboración continua de nuevos saberes.
<p>&nbsp;</p>


Enseñamos los aprendizajes vitales para un mundo cambiante
<p>&nbsp;</p>
Cuando educamos promovemos los aprendizajes vitales y ponemos los medios para asegurar que
un niño, un joven o un adulto los puedan incorporar a su vida. Se trata de un proceso continuo de
formación que tiene lugar de manera estructurada o informal.
<p>&nbsp;</p>
Un aprendizaje vital es aquel que determina nuestra capacidad para desarrollar adecuadamente un proyecto de vida en un mundo en cambio continuo.
<p>&nbsp;</p>
Entendemos por educación de calidad aquélla que aporta los aprendizajes que consideramos imprescindibles para el mundo en que nos toca vivir:
<p>&nbsp;</p>
•	el deseo de saber y el acceso a las fuentes del conocimiento.<p>&nbsp;</p>
•	la competencia en las tecnologías de la información y la comunicación.<p>&nbsp;</p>
•	la aceptación de la incertidumbre, porque en el mundo y en la vida no todo puede ser. aprehendido por el conocimiento humano.<p>&nbsp;</p>
•	la capacidad de relacionar las distintas áreas de aprendizaje, derribando las barreras tradicionales entre las disciplinas, para alcanzar una visión global de la realidad.<p>&nbsp;</p>
•	un método de enseñanza-aprendizaje que nos ayude a poner en práctica en la vida lo aprendido en el aula.<p>&nbsp;</p>
•	la capacidad de comunicación en otros idiomas.<p>&nbsp;</p>
•	la creatividad y el sentido de la belleza.<p>&nbsp;</p>
•	la sensibilidad y la indignación ética que nos abra los ojos al sufrimiento y la injusticia.<p>&nbsp;</p>
•	el espíritu de esfuerzo y sacrificio.<p>&nbsp;</p>
•	el aprecio de la cultura y la tradición que convierte la historia humana en maestra de vida.<p>&nbsp;</p>
•	el valor de aceptar los límites, la frustración, el dolor y los conflictos como parte de la vida.
•	la adaptación a los cambios culturales, tecnológicos y sociales.<p>&nbsp;</p>
•	la tolerancia y la acogida de las diferencias.<p>&nbsp;</p>
•	la capacidad de trabajar de forma cooperativa y de aprender en relación con los demás.<p>&nbsp;</p>
•	el sentido del bien común y la responsabilidad ante él.


		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

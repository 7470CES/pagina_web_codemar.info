﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">
<title>Colegio El Corazón De María</title>
     <link rel="stylesheet" href="css/estilosf.css">
     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">
	 <link rel="stylesheet" href="css/font-awesome.css">

	<script src="js/jquery-3.1.0.min.js"></script>
	<script src="js/main.js"></script>
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section id="seccion1">		
	  <article id="form">
		  <?php 
$myemail = 'direcciongeneral@cordemar.info';
$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$asunto = $_POST['asunto'];
$email = $_POST['email'];
$message = $_POST['mensaje'];

$to = $myemail;
$email_subject = "Nuevo mensaje: $subject";
$email_body = "Haz recibido un nuevo mensaje. \n Nombres: $nombres \n Apellidos: $apellidos \n Asunto: $asunto \n Correo: $email \n Mensaje: \n $message";
$headers = "From: $email";

mail($to, $email_subject, $email_body, $headers);
echo "<script type=\"text/javascript\">alert(\"Email Enviado\");</script>";  
?>
		<form class="contact_form" method="post" action="enviar.php">
		<ul>
			
			<li>
			<label for="website">Nombres</label>
            <input type="text" name="nombres" />
			
			
			</li>
			<li>
			<label for="website">Apellidos</label>
            <input type="text" name="apellidos" />
			
			
			</li>
			<li>
			<label for="website">Asunto</label>
            <select name="asunto">
		   <option value="Preguntas">Solicitud de Documentos</option>
		  <option value="Preguntas">Solicitud de Verificación</option>
		 <option value="Preguntas">Preguntas, Sugerencias y Quejas</option>
		  <option value="Preguntas">Solicitud De Cupos</option>
			  </select>
			
			
			</li>
			<li>
			<label for="website">Email</label>
            <input type="email" name="email" />
			
			
			</li>
		  <li>
			<label for="website">Mensaje</label>
            <textarea type="text" name="mensaje"  rows="10" cols="32"></textarea>
			
			
			</li>
			<li>
    <button class="submit" type="submit">Enviar</button>
			</ul>
</form>
		<hr style="color: white"/>
		ASTRID STELLA CORTES ACOSTA<br>
Directora Académica 9ª, 10ª y 11ª
		<hr style="color: white"/>
LUIS ALBERTO DIAZ DONOSO<br>
Coordinador Bienestar Estudiantil Bto. 6ª, 7ª y 8ª
		<hr style="color: white"/>
YAMILE MONSALVE GAVILAN <br>
Subdirectora Académica Bto. 6ª, 7ª y 8ª
		<hr style="color: white"/>
CLAUDIA PATRICIA RINCON <br>
Directora de Bienestar Estudiantil 9ª, 10ª y 11ª
		<hr style="color: white"/>
YANETH DEL PILAR AMAYA OTÁLORA <br>
Subdirectora académica de Infantiles
		<hr style="color: white"/>
NANCY MILENA RUBIANO <br>
Coordinadora de bienestar estudiantil de infantiles
		<hr style="color: white"/>
MARIA EUGENIA CABEZAS MEJIA <br>
Coordinadora Programas Especiales
		<hr style="color: white"/>
JAIME ARTURO BAEZ AGUDELO <br>
Director de Pastoral
		<hr style="color: white"/>
OLGA LUCIA IZQUIERDO MORA <br>
Representante Dirección SGC
		<hr style="color: white"/>
CONSEJO DE PADRES <br>
Consejo de Padres
		<hr style="color: white"/>
ASOCIACION DE PADRES DE FAMILIA <br>
Asociación de Padres
GONZALEZ RIOMAÑA MIGUEL ANGEL <br>
Webmaster
		<hr style="color: white"/>
ANDREA GELVEZ <br>
Primeros Auxilios
		<hr style="color: white"/>
FLORELBA MERCHAN RIAÑO <br>
Tesorería
		<hr style="color: white"/>
MERCEDES DEL PILAR ROMERO AREVALO <br>
Auxiliar Administrativa
		<hr style="color: white"/>
MARÍA ALEJANDRA BARRERA MOLANO <br>
Secretaria Académica
		<hr style="color: white"/>
SONIA CRISTANCHO <br>
Recepcionista / Secretaria de Bienestar Estudiantil
		<hr style="color: white"/>
CLAUDIA ROCIO DUARTE DUARTE <br>
Coordinadora de Rutas
		<hr style="color: white"/>
MARÍA ALEJANDRA BARRERA <br>
Secretaria General
		<hr style="color: white"/>
		</article>
</section>
		
		<hr style="color: white"/>
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>
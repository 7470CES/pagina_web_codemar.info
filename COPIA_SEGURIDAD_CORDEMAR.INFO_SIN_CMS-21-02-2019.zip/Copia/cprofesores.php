﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CLAUSTRO DE PROFESORES</title>
	<link rel="stylesheet" href="css/estilosacerca.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/profesores.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>CLAUSTRO DE PROFESORES</center></strong>
			<p>&nbsp;</p>
			Se conoce con este nombre al cuerpo de profesores que dirigen y regentan las áreas, asignaturas y cátedras del Colegio El Corazón de María.      Pertenecen a este, miembros activos de Cordemar Azul,  y que se desempeñan como docentes.   También otros que no son miembros activos pero que prestan sus servicios a la institución.
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

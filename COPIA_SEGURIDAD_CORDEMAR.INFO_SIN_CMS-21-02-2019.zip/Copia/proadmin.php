﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PROCESO DE ADMISIÓN</title>
	<link rel="stylesheet" href="css/estilossinstievalpro.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
		<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<strong><center>PROCESO DE ADMISIÓN</center></strong>
			<p>&nbsp;</p>
			Cualquier persona puede solicitar la admisión de su hijo o hija,  o menor bajo su tutela,  para que curse estudios en el Colegio El Corazón de María, CORDEMAR.    Pero debe saber, que somos un colegio privado,  y que por lo tanto se requiere una relación contractual,  que solo puede hacerse con un mayor de edad, que se comprometa a representar al menor y a cumplir las obligaciones económicas concomitantes.
<p>&nbsp;</p>
Las pre-matrículas para el año siguiente al que esté en curso comienzan a partir de la tercera Semana de Octubre.    La solicitud de cupos puede hacerse en cualquier momento del año.
<p>&nbsp;</p>
Las matrículas se pueden realizar en: 
<p>&nbsp;</p>
La primera semana de Diciembre, en días hábiles en el horario de Oficina:  De 8:00 Am  a 12:00M  y de 4:00 PM  a  6:00 PM.
<p>&nbsp;</p>
En la tercera semana de Enero,  en días hábiles en el horario de Oficina:   De 8:00 Am  a 12:00 M
Y de 4:00 PM a 6:00 PM.

<p>&nbsp;</p>
Son requisitos de ingreso los siguientes:
			<p>&nbsp;</p>

•	Un adulto responsable que asuma la representación del menor y las obligaciones económicas derivadas del servicio educativo contratado.  Haber firmado el contrato de matrícula y el pagaré correspondientes.<p>&nbsp;</p>
•	Fotocopia del Acudiente al 150% por lado y lado<p>&nbsp;</p>
•	Una carpeta pre-forrada de color azul,  con celuguía <p>&nbsp;</p>
•	Registro civil<p>&nbsp;</p>
•	Certificados de estudio de los grados cursados<p>&nbsp;</p>
•	Certificado médico<p>&nbsp;</p>
•	Fotocopia del carné de la EPS<p>&nbsp;</p>
•	Fotocopia del carné del SISBEN <p>&nbsp;</p>
•	Fotocopia del recibo de energía eléctrica de la casa en la que reside<p>&nbsp;</p>

<p>&nbsp;</p>
Si el menor proviene del sector público de educación,  el acudiente del alumno debe adicionar una constancia de trabajo vigente firmada por su empleador,  y una constancia de buena conducta del alumno.<p>&nbsp;</p>

Existen impedimentos especiales de matrícula para aquellos alumnos que por su situación o por sus responsabilidades adquiridas no puedan cumplir completamente con sus deberes académicos.  Estos impedimentos son los siguientes:<p>&nbsp;</p>

•	Que el alumno o alumna se encuentre unido por vínculo matrimonial o unión libre, y que en cualquier caso haya iniciado vida conyugal.<p>&nbsp;</p>

•	Alumnas que tengan hijos de cualquier edad, y deban cumplir con sus deberes de madre, es decir todo aquello que tenga que ver con la atención, cuidado, alimentación, tutela, de su hijo.
<p>&nbsp;</p>
•	Alumnos o alumnas que se encuentren trabajando más de 3 horas diarias en algún establecimiento o por cuenta propia.<p>&nbsp;</p>

•	Alumnas que se encuentren en estado de embarazo  en el momento de la matrícula.<p>&nbsp;</p>

•	Alumnos o alumnas que tengan un problema de aprendizaje severo que requiera el concurso de un especialista.  O un servicio especializado para su caso.<p>&nbsp;</p>

•	Alumnos o alumnas que considerándose homosexuales o lesbianas manifiestan formalmente que  tienen el interés y la intención de llevar a cabo actividades de proselitismo político a favor de alguna comunidad LGBTI dentro del colegio o con menores del colegio.<p>&nbsp;</p>

•	Alumnos o alumnas que declaren formalmente que son o se consideran parte de una religión satánica y tienen el interés de llevar a cabo actividades de proselitismo a favor de dicha comunidad dentro del colegio o con menores del colegio.  <p>&nbsp;</p>

•	Alumnos o alumnas que tengan reseña en su pasado judicial, o una mala reputación en la sociedad de Codazzi.  (Falta GV.17 estipulada en el artículo 130 del Manual de Convivencia Social) <p>&nbsp;</p>


Nota Aclaratoria 1:   Las alumnas que queden en estado de embarazo durante el año lectivo continuarán con sus deberes académicos y su estado no afectará en nada su permanencia en la institución, mientras termina el año escolar.<p>&nbsp;</p>



Existen también algunas contraindicaciones de matrícula que impiden que un menor pueda ingresar al Colegio El Corazón de María,  o pueda continuar estudios en él;    estos son:<p>&nbsp;</p>


•	Que presente un cuadro de adicción a drogas alucinógenas.<p>&nbsp;</p>

•	Que presente un cuadro de adicción al alcohol.<p>&nbsp;</p>

•	Que esté vinculado a alguna asociación juvenil que se vea envuelta en disturbios y actos delictivos, destructivos o vandálicos.  (Pandillas)<p>&nbsp;</p>

•	Alumnos y alumnas que estando matriculados en el colegio decidan unirse en matrimonio o unión libre durante el año lectivo.<p>&nbsp;</p>

•	Que un Padre de Familia o Acudiente haya amenazado, golpeado, o protagonizado un acto de violencia en el colegio,  contra cualquiera de los miembros de la Comunidad Educativa (Alumno, exalumno, egresado, padre de familia, auxiliar de servicios, funcionario, contratista, profesor, o directivo).








		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

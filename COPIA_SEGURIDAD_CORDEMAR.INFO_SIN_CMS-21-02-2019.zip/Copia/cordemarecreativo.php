﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CORDEMAR RECREATIVO</title>
	<link rel="stylesheet" href="css/estiloscordemaracadem.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/cordemar_recreativo.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>CORDEMAR RECREATIVO</strong></h1>
			<p>&nbsp;</p>
	Enseñar hábitos de estudio y el buen manejo del tiempo libre a nuestros alumnos es un objetivo que nos compromete por igual a Profesores y Padres de familia. 

El sano esparcimiento y la diversión de nuestros niños son parte importante en nuestro currículo.  El equilibrio entre actividades académicas y lúdicas es una preocupación constante.

Es el Consejo Estudiantil elegido democráticamente quien propone las actividades recreativas que se incluirán en el cronograma institucional de cada semestre.    Jornadas culturales,  jornadas deportivo-culturales,  salidas pedagógicas,  paseos,  convivencias,  campamentos,  retiros  y excursiones.

Las actividades se realizan de acuerdo al plan operativo,  cumpliendo con las normas establecidas para tal efecto,  siempre contando con el número suficiente de profesores que ayuden a mantener el orden,  y de integrantes de la Junta de Padres de Familia que garantizan la supervisión del estamento que representan.   El alumno debe mantener el comportamiento y orden estipulado en el Manual de Convivencia Social del Colegio.	<p>&nbsp;</p>

Cada vez que se realizarán dichas actividades primero se hacen las respectivas comunicaciones formales a cada uno de los padres de familia.  Que decide si su hijo participará o no, en ellas.	<p>&nbsp;</p>

Todo alumno para poder asistir a estas actividades,  debe:	<p>&nbsp;</p>

•	No estar sancionado con suspensiones por mal comportamiento y haber cometido faltas consideradas en el Manual de Convivencia.	<p>&nbsp;</p>

•	Tener el permiso de su acudiente (Padre o Madre de Familia)	<p>&nbsp;</p>

•	Contar con el valor del costo de dicha actividad. 	<p>&nbsp;</p>




		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

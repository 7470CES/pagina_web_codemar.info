﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Nuestros Simbolos</title>
	<link rel="stylesheet" href="css/estilosnsimbolos.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/cordemar_simbolos.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>NUESTROS SIMBOLOS</center></strong>
			<p>&nbsp;</p>
			Son símbolos de nuestra institución:
<p>&nbsp;</p>
El Escudo Académico:
El escudo académico, es un escudo suizo, que se caracteriza por su sencillez; para nosotros simboliza la virtud que identifica a los verdaderos maestros, a aquellos que descubren y enfocan las aptitudes naturales de sus discípulos, orientándolos y desarrollando en ellos habilidades propias de su talento; con total entrega desinteresada a su quehacer.
<p>&nbsp;</p>
Con bordura de plata y en campo de azur, se destacan en plata, un monograma con las iniciales del corazón de María entrelazadas C y M, que hace clara alusión a que somos seguidores de “Santa María, Madre Protectora y Maestra Paciente”.   Al monograma lo rodean dos ramas de laurel en plata, significando la victoria del conocimiento sobre la ignorancia.
<p>&nbsp;</p>
Así pues, el escudo académico representa en nuestra institución la labor formativa.  Todo aquello que hacemos en la enseñanza y  promoción de saberes.  La labor específica de sembrar la semilla del saber en las mentes y los corazones de nuestros alumnos.
<p>&nbsp;</p>

El Escudo Organizacional:
Sin seguir las tradicionales reglas de la heráldica,  el escudo organizacional es un escudo de trazos lineales, que evoca una consolidación de estructuras que semeja una figura autóctona de América.  Las diferentes partes del escudo son de colores plata (blanco) y azur (azul) alternativamente, y las líneas que dividen y bordean la estructura son doradas. En su interior se encuentra un campo partido al medio, de azur (Azul) y plata (Blanco) en el que se destaca el escudo académico, con su característico monograma C y M, entrelazadas, que representa el Corazón de María,  Madre del Mesías esperado, el Cristo, príncipe de paz. Que compromete al colegio en su quehacer, a imitar las cualidades y virtudes de María, y seguir a Jesucristo.   
<p>&nbsp;</p>
Bordeando el interior del escudo, en la sub-estructura que sigue, se encuentra el lema: “Dios, Honor, Disciplina, Excelencia”, que sintetiza los pilares sobre los que se afianza la formación impartida a los educandos.  Sobre la estructura de trazos lineales, reposa un águila abstracta que representa la luz de Cristo, revelada por San Juan, el apóstol y evangelista, y que señala nuestro papel  como discípulos de Cristo y de su apóstol Juan; y de seguidores visionarios, que comprometen a la institución  a liderar los procesos de sensibilización, concientización, y educación de la sociedad que lo circunda, a través de la promoción de saberes y conocimientos que eleven el nivel de cultura y civilización, sin dejar de promocionar e inculcar los valores del Cristianismo.
<p>&nbsp;</p>


La Bandera:
La Bandera del colegio “El Corazón de María”, está conformada por dos franjas horizontales de igual dimensión.  La primera franja es de color blanco que simboliza la virtud, que en nuestro caso específico se refiere a la vocación de enseñar.  La segunda franja es de color azul rey que simboliza la frialdad de la razón, el recogimiento, la verdad y la sabiduría.

<p>&nbsp;</p>
El Logotipo:
El logotipo publicitario con que se identifica el colegio, es un rectángulo de color azul rey, que contiene en su interior la sigla que abrevia el nombre, en letras blancas.  La sigla es “Cordemar”.

	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

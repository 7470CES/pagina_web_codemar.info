﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Misión</title>
	<link rel="stylesheet" href="css/estilosacerca.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/colegio.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>MISIÓN</center></strong>
			<p>&nbsp;</p>
			Somos el Colegio “El Corazón de María” de Agustín Codazzi,  una institución de Educación Formal, laica,  de carácter privado, sin ánimo de lucro, y de población mixta;  que ofrece a los niños y jóvenes  una formación integral de alta calidad,  proveniente de una cultura y tradición occidental, 
cristiana, republicana y de inclinación económica liberal.
<p>&nbsp;</p>
Que defiende el derecho a la vida, el derecho a la libertad, el derecho a la propiedad, y a la búsqueda de la felicidad.   Cumpliendo con los requisitos del Estatuto de Educación Nacional, 
de la República de Colombia.
<p>&nbsp;</p>
El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.


	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CURSOS PRE-SABER ICFES</title>
	<link rel="stylesheet" href="css/estilospresaber.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<h1><strong><center>CURSOS PRE-SABER ICFES</center></strong></h1>
			<p>&nbsp;</p>
			Son cursillos que tienen como objetivo primordial mejorar el resultado académico en las Pruebas SABER ICFES que presentan los alumnos de 3º, 5º, 7º, 9º, y 11º, respectivamente.
<p>&nbsp;</p>
Utilizan un conjunto de herramientas pedagógicas diseñadas para facilitar la reflexión y el seguimiento a las metas inteligentes que se establecieron el Día de la Excelencia Educativa (Marzo 25 de 2015).  Tienen en cuenta:
			<p>&nbsp;</p>

•	Las orientaciones pedagógicas para mejorar los aprendizajes de los estudiantes según las Pruebas SABER ICFES.<p>&nbsp;</p>

•	La Matriz de referencia utilizada por el ICFES para el diseño de las Pruebas SABER.<p>&nbsp;</p>

•	Los Derechos Básicos de Aprendizaje, que constituyen los conocimientos elementales de un estudiante para un grado determinado.<p>&nbsp;</p>

•	Y los resultados institucionales en las PRUEBAS SABER ICFES, articulados al Índice Sintético de la Calidad Educativa (ISCE), que nos indica los aprendizajes para cada grado y área que requieren mayor apropiación.<p>&nbsp;</p>

•	Las estrategias didácticas y pedagógicas propuestas por el Ministerio de Educación Nacional, para conseguir que Colombia sea la más educada de Latinoamérica en el año 2025.<p>&nbsp;</p>

Pueden realizarse en tiempo de jornada complementaria o en el tiempo de clase ordinaria, bajo la dirección del profesor que regenta la asignatura.   En la medida que exijan tiempo adicional pueden generar un costo adicional que debe ser asumido por los padres de familia.



	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

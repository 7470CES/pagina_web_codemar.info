﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Nuestros Pilares</title>
	<link rel="stylesheet" href="css/estilosnpilares.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<strong><center>NUESTROS PILARES</center></strong>
			<p>&nbsp;</p>
			El lema del colegio es en donde se sintetizan los cuatro pilares sobre los cuales se fundamenta la formación que impartimos a nuestros educandos.  El lema del colegio está formulado como a continuación se presenta:
			<p>&nbsp;</p>

“DIOS, HONOR, DISCIPLINA, EXCELENCIA”.
			<p>&nbsp;</p>

DIOS: Porque somos un colegio de religión cristiana, y según nuestras creencias, el Dios de Israel, es el ser supremo, creador de todo cuanto existe, y director máximo de su creación; por lo tanto es el principio de todo conocimiento verdadero, y el único que puede otorgar sabiduría.
<p>&nbsp;</p>
HONOR: Porque es el más alto premio que se nos puede otorgar como mortales.  Es una dignidad que solo puede ser otorgada por tener en cuenta el mérito de una persona íntegra.  El  Honor no es algo que se compra o se mendiga, al contrario, es algo que se merece.
<p>&nbsp;</p>
DISCIPLINA: Porque es el método que organiza nuestro trabajo, por lo tanto constituye la mejor forma de lograr lo que nos proponemos.  Siempre y cuando nos apliquemos al esfuerzo con constancia y decisión.
<p>&nbsp;</p>
EXCELENCIA: Porque debemos ser capaces de concebir perfecciones y de vivir hacia ellas.  Porque se debe mirar alto y lejos, nadando contra todas las corrientes rebajadoras, planeando nuestra vida, sirviéndole  a un ideal, perseverando en nuestra ruta, sintiéndonos dueños de nuestras acciones, templándonos por grandes esfuerzos, seguros de nuestras creencias, leales a nuestros afectos, fieles a nuestra palabra, con una firme línea moral que nos identifique.  Porque debemos liderar a nuestros semejantes como verdaderos visionarios.  Agrediendo los errores del pasado y preparando el porvenir.  Resistiéndonos a todo influjo de mediocridad.

	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

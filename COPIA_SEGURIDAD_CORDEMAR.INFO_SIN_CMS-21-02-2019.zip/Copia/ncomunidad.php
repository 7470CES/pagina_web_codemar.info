﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>NUESTRA COMUNIDAD</title>
	<link rel="stylesheet" href="css/estiloshistory.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<h1><strong><center>NUESTRA COMUNIDAD</center></strong></h1>
			<p>&nbsp;</p>
		  Nuestra Comunidad Educativa está conformada por todos nuestros estamentos, más grupos conexos que adelantan acciones y proyectos en conjunto con el colegio, o son un apéndice de este.
	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

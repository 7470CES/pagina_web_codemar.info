﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ENTRENAMIENTO DEPORTIVO</title>
	<link rel="stylesheet" href="css/estilosedeportivo.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/voleibol.png" width="400" height="350" alt=""/></article>
		<article id="right">
			<h1><strong><center>ENTRENAMIENTO DEPORTIVO</center></strong></h1>
			<p>&nbsp;</p>
			En el Colegio El Corazón de María se practican tres deportes: el volley  ball,  el micro futbol y el Ajedrez.    Los alumnos que luego de haber participado en los juegos escolares de casas, y habiendo encontrado cierta predilección por algunos de los deportes mencionados,  pueden dedicar parte de su tiempo a la práctica de uno de esos deportes,  al ser convocados al equipo institucional o selección del colegio,  para que inicien el programa de entrenamiento con fines competitivos.<p>&nbsp;</p>

Tienen un horario específico de clase, práctica, y competición;  en jornada contraria.   Dos veces por semana.<p>&nbsp;</p>



		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

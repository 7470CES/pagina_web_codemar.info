﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Nuestro Modelo Pedagogico</title>
	<link rel="stylesheet" href="css/estilosacerca.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<strong><center>NUESTRO MODELO PEDAGOGICO</center></strong>
			<p>&nbsp;</p>
			Nuestro Modelo pedagógico está fuertemente influenciado por nuestra Comunidad Laica Marianista.    Y se inspira en el carisma de los fundadores de la familia marianista,  el Padre Guillermo José Chaminade y la Madre Adela de Batz de Trenquelleon.
<p>&nbsp;</p>
Como laicos marianistas,  nuestra propuesta está basada en la persona y el mensaje de Jesús de Nazaret. Encontrando en María el modelo de educador. Ella nos invita a “acoger la Palabra de Dios y ponerla en práctica”, a comprometernos en nuestra misión, siguiendo a Jesús: “Haced lo que Él os diga".     La misión básica de nuestro colegio es educar a niños y jóvenes para que lleguen a realizarse integralmente como hombres y mujeres que encuentran el sentido de su vida en una visión cristiana de la persona y del mundo. 
<p>&nbsp;</p>
Como marianistas,  creemos que “educar es colaborar con Dios en formar hombres y mujeres, conscientes de sí mismos y del mundo que les rodea y comprometidos en la tarea de transformar la sociedad para hacerla más justa y fraterna”.  


		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Educamos Para Formar Un Nuevo Tipo De Persona</title>
	<link rel="stylesheet" href="css/estilosedufornuper.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/npersonas.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>EDUCAMOS PARA FORMAR UN NUEVO TIPO DE PERSONA</center></strong>
			<p>&nbsp;</p>
			Fieles a nuestra fe en Jesús y María, el colegio realiza su trabajo en la perspectiva del diálogo fe-cultura-vida, permaneciendo abierto a todos,  como servicio a la sociedad en la que vive;    esforzándose por extender la tarea educativa y evangelizadora a todos los integrantes de su comunidad educativa.
<p>&nbsp;</p>
Somos un colegio católico y los retos que tenemos planteados como cristianos católicos son, pues, la transmisión de una visión cristiana de la vida y la educación integral de niños y jóvenes desde los valores del evangelio.
<p>&nbsp;</p>
Toda práctica educativa tiene su fundamento en una antropología, es decir, en un modelo de hombre y mujer. Esta elección no excluye, en modo alguno, el respeto al crecimiento y a las peculiaridades de cada alumno, así como a las opciones que pueda ir tomando en su vida.  Sin embargo, no hay educación neutra; todo educador y toda organización escolar transmite  una visión de la vida y un modo particular de ser persona. Detrás de cada acción educativa subyace la misma intención: ir perfilando un modelo de persona con unas determinadas señas de identidad, un modo de sentir, de actuar y de enfrentarse a la vida.
<p>&nbsp;</p>
En nuestra concepción, los seres humanos son corporeidad, intelecto, emociones y sentimientos, capacidad de relación, espiritualidad, apertura a la trascendencia y acción en el mundo.
Queremos educar todas estas dimensiones de manera armónica y ayudar a la integración de toda la persona en un proyecto vital.  Cada individuo es el resultado de la herencia y del medio, pero también de su propio crecimiento y desarrollo. Por lo tanto, es un ser abierto, capaz de elegir, y puede, mediante la voluntad,  mejorarse a sí mismo y aprender a vivir.
<p>&nbsp;</p>
Jesús de Nazaret es nuestro primer modelo: rostro y palabra de Dios, pero también el proyecto más pleno y acabado de hombre. Su vida nos inspira un ideal de hombre y mujer que puede ser acogido desde la libertad.
<p>&nbsp;</p>
“Hablar de educación es hablar más de semillas que de frutos, más de siembra que
de cosecha; es trazar un rumbo y ponerse en camino.  Educar supone guiar desde fuera para dejar nacer todo lo bueno, lo bello y lo verdadero que la persona lleva dentro. Educar significa intervenir positivamente para hacer crecer”.



		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

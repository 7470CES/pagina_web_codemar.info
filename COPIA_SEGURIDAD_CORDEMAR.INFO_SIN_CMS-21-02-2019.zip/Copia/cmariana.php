﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CONGREGACIÓN MARIANA</title>
	<link rel="stylesheet" href="css/estiloscmariana.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/congregacion.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>CONGREGACIÓN MARIANA</center></strong></h1>
			<p>&nbsp;</p>
		La Congregación Mariana del Colegio El Corazón de María,  tiene las características de una Comunidad Laica Marianista,   cuyo nombre formal es:  “Fraternidad del Corazón de María y San Juan Evangelista de la Esperanza”,  y está vinculada a las Comunidades Laicas Marianistas de Colombia, de las que hace parte. 
<p>&nbsp;</p>
Tiene como misión salvaguardar la doctrina mariana en la institución y dirigir el Proyecto Pastoral con los alumnos y la Comunidad Educativa,  siguiendo las orientaciones de religiosos y laicos marianistas consagrados, que la asesoran.  
<p>&nbsp;</p>
Se define así:
<p>&nbsp;</p>
“En este grupo estamos los Cordemarianos que reconocemos en María, Madre de Jesús, las virtudes y cualidades del buen cristiano. Los que celebramos ese vínculo especial que Jesús estableció con todos nosotros, a través de Juan el apóstol; cuando frente a la cruz del Calvario, encargó a María el apóstol que amaba, y al apóstol que amaba encargó a su madre. "Madre he ahí a tu hijo, Hijo he ahí a tu Madre"... 
<p>&nbsp;</p>
Los que vemos en María a una Maestra... y estableciendo una alianza con María, abrazamos su magisterio y seguimos a Jesús, Nuestro Señor. 
<p>&nbsp;</p>
Los que trabajamos para que el CORDEMAR profundice sus raíces marianas, realice una obra evangelizadora, y apoye la expansión del Reino de Dios en la Tierra. 
<p>&nbsp;</p>
Somos la Congregación Mariana del Colegio El Corazón de María de Agustín Codazzi, Cesar, Colombia”...
<p>&nbsp;</p>


Horario de reuniones:    Todos los miércoles a las 6:00 PM en las instalaciones del Colegio El Corazón de María.

	    </article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

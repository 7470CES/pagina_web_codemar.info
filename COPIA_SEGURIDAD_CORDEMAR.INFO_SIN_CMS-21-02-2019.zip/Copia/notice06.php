﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">
<title>NOTICE#6</title>
     <link rel="stylesheet" href="css/estilosnotice.css">
     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">
	 <link rel="stylesheet" href="css/font-awesome.css">

	<script src="js/jquery-3.1.0.min.js"></script>
	<script src="js/main.js"></script>
	<script language="javascript" src="js/validacion.js"></script>
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section id="seccion1">		
	  <article id="leftnotice">
		<hr style="color: white"/>
		  <p><strong>‘¿QUÉ PASARÁ CON LAS ACTIVIDADES COMPLEMENTARIAS EN HORAS DE LA TARDE?
		  <hr style="color: white"/></strong></p>
		  <p>&nbsp;</p>
		  
	  <div id="img"><img src="img/obligatoriedad de cursos de refuerzo para alumnos de bajo rendimiento.jpg" alt="" style="float:left; width:393px; height: 400px"/></div> La cartera explica cómo funcionará la ley que obliga a que se enseñe esta asignatura.
 <p>&nbsp;</p>
		  
Por: Silvia Andrea Henao Ortega</br>
 <p>&nbsp;</p>
		  
Las actividades complementarias en las horas de la tarde, consideradas por unos, como el complemento  necesario para desarrollar en el alumno destrezas y habilidades concomitantes al proceso de aprender conocimientos, de temas incluidos en programas académicos tan importantes como matemáticas, y español;  tienen dividida a la Comunidad Educativa Cordemariana.    

		   <p>&nbsp;</p>
		  
Por otro están quienes no  les gustan las clases de tarde, pero que de todas formas asisten porque el padre de familia los obliga a ir.   De alguna forma sienten que lo agradable de la tarde es el recreo y socializar con los compañeros.

 <p>&nbsp;</p>
		  
Y por otro lado están aquellos que les parece importante la realización de tales ejercicios y el desarrollo de las asignaturas consideradas complementarias,  pero que están mal planteadas en la tarde, porque en verdad no es la totalidad de alumnos la que asiste.   Y en ocasiones, los profesores se quedan cortos para asegurar la asistencia a clase de los alumnos de más bajo rendimiento.    

 <p>&nbsp;</p>
		  
Y tal como se aseveró en los debates de Diciembre.   Los alumnos de más alto rendimiento, que cuentan con el apoyo de un padre responsable que se preocupa porque ellos cumplan con sus deberes escolares, logran obtener una ventaja absoluta frente a esos otros chicos de bajo rendimiento cuyos padres no se aseguran de que asistan a la jornada complementaria.  En consecuencia los alumnos de más alto rendimiento, cumplidores de su deber, alcanzan calificaciones muy altas y los alumnos que más necesitan los ejercicios de destreza y el seguimiento académico obtienen calificaciones mediocres o realmente bajas.    
<p>&nbsp;</p>
Se demostró que no son los niños de bajo rendimiento los que aprovechan estas actividades y esta metodología se pensó y se implementó para lidiar con los bajos resultados de niños deficientes.  Es decir como respuesta institucional para retroalimentar, y trabajar en las deficiencias detectadas de los alumnos que no alcanzan los objetivos académicos propuestos.

<p>&nbsp;</p>
Mucho se dijo en el debate al respecto,  incluso se reconoció tanto en la Afirmativa (liderada por María Clara Iguarán) como en la  Negativa (liderada por Claudia Patricia Barrios),  cierta inconciencia de parte de alumnos y padres, acerca de la importancia de desarrollar las competencias establecidas en Colombia para determinar la suficiencia de los alumnos de un grado.    Cosa que de alguna forma también se considera una de las causas más relevantes de las bajas puntuaciones de la población estudiantil codacense que presenta la Prueba de Estado en Agosto.     Tristemente dijo María Clara, “en Codazzi, las familias prefieren optar por caminos fáciles para el ingreso de sus hijos a la Universidad, siempre utilizando tráfico de influencia y pagos extra con los que se cree aseguran los cupos en las distintas facultades”.   En algunos apartes de su intervención Claudia Patricia, reconoció que “el deseo de trabajar en las minas de carbón como operador de camión, hace pensar al alumno que no necesita saber casi nada para realizar una actividad tan rutinaria, considerada realmente fácil –manejar-, eso afecta gravemente el desempeño de un estudiante en Codazzi hoy, especialmente cuando a factorizar o resolver ecuaciones se refiere”.  
<p>&nbsp;</p>
Sin embargo el punto álgido del debate, se dio en si esas actividades complementarias deben mantenerse como obligatorias para todos los alumnos cordemarianos en las áreas de Matemáticas y Español.   Y la conclusión del jurado, fue que “la jornada de la tarde como se ha venido implementando debe ser profundamente reformada, y las actividades de refuerzo y consideradas “remediales”, deben ser realizadas por los alumnos para los cuales fueron creadas; los alumnos de bajo rendimiento que muestran evidencia inequívoca de deficiencia académica en esas áreas. Entonces dichas actividades deben ser obligatorias no para la totalidad de estudiantes, sino para los deficientes, y queda de parte de la Rectoría del Colegio, informar, notificar, y acordar con los padres de dichos chicos la realización efectiva de tales actividades”.
<p>&nbsp;</p>
En el debate, el jurado de Cordemar Azul, concedió 10 votos a favor, de 13 existentes,  a la iniciativa liderada por María Clara Iguarán y Andrea Carolina Saavedra, que versaba sobre “La Obligatoriedad para el alumno de bajo rendimiento de participar en las actividades de refuerzo y el curso remedial”.  Que ya cursa su tránsito en el Consejo Académico y en el Consejo Directivo del Colegio El Corazón de María, para formalizar su aprobación.  



		 



		  <hr style="color: white"/>
		
		</article>
</section>
		
		<hr style="color: white"/>
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

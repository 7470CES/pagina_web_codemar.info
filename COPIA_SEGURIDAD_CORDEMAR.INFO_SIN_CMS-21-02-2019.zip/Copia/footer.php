<center>COLEGIO EL CORAZÓN DE MARÍA<br>
Carrera 18 No. 15-59 Agustin Codazzi - Cesar-Colombia - Tel.: 5767353 - 3153295086<br>
E-mail: colegioelcorazondemaria@cordemar.org
			<p>&nbsp;</p></center>
﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CORDEMAR ECOLÓGICO</title>
	<link rel="stylesheet" href="css/estiloscordemaracadem.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/cordemar_ecologico.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>CORDEMAR ECOLÓGICO</strong></h1>
			<p>&nbsp;</p>
	Somos un colegio ecológico, creemos que si fomentamos en nuestros niños y jóvenes, 
el aprecio y el respeto por la vida, tendremos adultos compasivos, responsables de sus actos, 
y comprometidos con mantener un clima de armonía, progreso y paz en nuestro país.
<p>&nbsp;</p>
En su defensa de la Vida, el colegio en 1992, optó por fundar 
la Asociación Defensora de Animales y del Ambiente (ADA) de Codazzi,   hoy ADACODAZZI,
con la que lucha contra la crueldad con los animales 
y trabaja por fomentar un mejor trato a la naturaleza 
y un mejor uso de los recursos naturales.
<p>&nbsp;</p>
Ha intervenido en la erradicación de la práctica 
de sacrificar animales vivos en los colegios y escuelas del departamento, 
en combatir el sobrepeso y el maltrato a los caballos de los carros de tracción animal, 
en la asistencia y control de los perros callejeros, 
en impedir los actos de crueldad de automotores y transeúntes contra ellos,
En la reforestación del municipio,  
Y enseñando con el ejemplo a sus alumnos, 
prácticas de caridad y buen trato a sus mascotas.
<p>&nbsp;</p>
Es nuestro compromiso institucional
Con el medio ambiente y la naturaleza…
<p>&nbsp;</p>
“Por eso en cada hogar donde exista uno de nuestros alumnos,
En cada lugar donde brille una de nuestras insignias,
Hay alguien que respeta y defiende la vida,
Allí siempre habrá alguien que defienda al perro callejero,
Al caballo sobrecargado, al animal silvestre,
Y le recuerde a los inconscientes, a los despiadados…
Que la crueldad, la insensibilidad y la violencia
No son comportamientos correctos”…
<p>&nbsp;</p>
(Aparte del discurso de la Profesora Rosita Del Castillo, Directora del Colegio, en el Marco del Décimo Desfile y Reinado Ecológico ADA-CORDEMAR en 2009)


		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

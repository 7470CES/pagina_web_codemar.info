﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Apostamos por la dignidad de la persona</title>
	<link rel="stylesheet" href="css/estiloseduintedecali.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<strong><center>Apostamos por la dignidad de la persona</center></strong>
			<p>&nbsp;</p>
			La tradición pedagógica marianista considera al niño o al joven como un ser único, irrepetible, vulnerable y, por tanto, merecedor de respeto en toda circunstancia. Cualquier intervención educativa se realiza desde ese respeto inviolable a la persona.
<p>&nbsp;</p>
Pero el ser humano no vive en soledad, es a la vez cultural, social e histórico. No se puede concebir de manera ajena a los grupos a los que pertenece. Hablar de la dignidad de una persona es hablar de la dignidad de todo ser humano.
<p>&nbsp;</p>
• Nuestra tradición nos empuja a prestar una atención singular a la personalidad de cada alumno,  valorar sus aptitudes e intereses y despertar en él todas sus potencialidades, convirtiéndole en principal protagonista de su propia maduración.
<p>&nbsp;</p>
• Interpelamos a nuestros alumnos para que tomen conciencia de su responsabilidad con el
mundo, donde todos estamos llamados a vivir en fraternidad. Cuando educamos a un niño
estamos contribuyendo a mejorar el mundo en que vivimos.
<p>&nbsp;</p>
Trabajamos para que nuestros alumnos crezcan en todas sus dimensiones y capacidades
Educar es mucho más que transmitir conocimientos, es mucho más que instruir. En el colegio pretendemos que niños, adolescentes y jóvenes desarrollen al máximo sus capacidades y crezcan en todas las dimensiones de su persona. Entendemos así por educación integral el desarrollo armónico y gradual de todas estas dimensiones: cuerpo y mente, inteligencia y sensibilidad, sentido estético, sociabilidad, responsabilidad individual, espiritualidad. Todo ello contribuye a hacer a cada alumno competente para hacer realidad sus proyectos.
<p>&nbsp;</p>
Esto conlleva:
			<p>&nbsp;</p>

•	El desarrollo adecuado de su propio cuerpo y de una vida saludable<p>&nbsp;</p>
•	El desarrollo preciso y armonioso de su emotividad y su afectividad<p>&nbsp;</p>
•	El desarrollo intelectual, fundamentado en una enseñanza de calidad, que le permita progresar según sus capacidades<p>&nbsp;</p>
•	El desarrollo social que le capacite para comunicarse con los otros y para vivir en una sociedad plural en la que participe con su propio proyecto de vida<p>&nbsp;</p>
•	El desarrollo espiritual que le permita abrirse a la alteridad, a la trascendencia y a la búsqueda  de sentido para la propia vida.<p>&nbsp;</p>

El colegio debe despertar las inteligencias, capacidades, conciencias y actitudes. La educación integral  y de calidad es un instrumento al servicio de la construcción de la vida.
			<p>&nbsp;</p>
			Educamos para vivir en la verdad
<p>&nbsp;</p>
Educar es hacer personas libres. Entre los rasgos esenciales de nuestro estilo pedagógico está el amor a la verdad, que favorece una libertad responsable: “La verdad os hará libres” (Jn 8, 32). Educar en la verdad y en el amor a la verdad es un serio compromiso para el educador marianista.
En nuestra sociedad domina la persuasión de que no hay verdades absolutas, de que toda verdad es contingente y revisable y de que toda certeza es síntoma de inmadurez y dogmatismo. De ahí fácilmente puede deducirse que tampoco hay valores que merezcan adhesión incondicional y permanente.
<p>&nbsp;</p>
Porque existe la verdad y porque el ser humano está hecho para encontrarla en libertad, creemos que es posible asentar la vida personal y colectiva en un conjunto de certezas sobre el ser, el sentido de la vida y el actuar del hombre.
<p>&nbsp;</p>
Educar en la verdad implica:
<p>&nbsp;</p>
• Educar en el valor del conocimiento científico y humanista y en el rigor intelectual.<p>&nbsp;</p>
• Orientar hacia la verdad como meta posible, evitando tanto el relativismo absoluto,  como el
fundamentalismo fanático.<p>&nbsp;</p>
• Educar en la autonomía y la responsabilidad, en la honradez en el trabajo y la satisfacción por
la tarea bien hecha.<p>&nbsp;</p>
• Enseñar a vivir con autenticidad y transparencia, sin máscaras con las que ocultar la realidad.
Buscar la verdad supone una actitud de coherencia con la propia conciencia.<p>&nbsp;</p>
• Ayudar a que cada alumno viva desde la realidad de lo que él es y desde la aceptación de sí
mismo.<p>&nbsp;</p>
• Ayudar a desenmascarar con lucidez y valentía los ídolos de nuestro tiempo que alienan a la
persona.<p>&nbsp;</p>
• Formar la capacidad de discernimiento y de crítica, la iniciativa y la creatividad personal.<p>&nbsp;</p>
• Fomentar actitudes de apertura a la verdad del otro. <p>&nbsp;</p>Aprender a escuchar, cuestionando prejuicios personales y culturales. Buscar, a través del diálogo, la verdad.<p>&nbsp;</p>

Para los cristianos la verdad última sobre el ser humano no es una doctrina teórica, sino la persona
misma de Jesús, “camino, verdad y vida”. El encuentro con Él es una experiencia única que lleva a
conocer una verdad liberadora, capaz de hacer nuestra vida más humana.





		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('header.php');?>
			</footer>
</body>
</html>

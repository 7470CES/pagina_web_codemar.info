﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Visión</title>
	<link rel="stylesheet" href="css/estilosacerca.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/colegio.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>VISIÓN</center></strong>
			<p>&nbsp;</p>
			En el año 2019, el Colegio El Corazón de María, CORDEMAR,  será  una institución educativa que conservando su esencia católica brinda una formación integral acreditada bajo estándares nacionales.  Que:  1. Promueve en la Comunidad Educativa,  la formación en la Fe y la práctica de los valores cristianos en concordancia con el Carisma Marianista.   2. Evangeliza a las familias y fomenta la formación de comunidades laicas marianistas, dentro de un entorno fraterno basado en la equidad,  el honor,  y la excelencia.  3. Inspirada en el estilo mariano de iglesia y sociedad forma líderes éticos, que son agentes de humanización, progreso  y cambio para la sociedad, con una clara conciencia social, económica y política que  atentos a los signos de los tiempos, sean defensores de la vida y los valores democráticos con una clara inclinación económica liberal que favorece la propiedad privada, las libertades individuales y los derechos civiles.  4.  Y dispuesta a aportar para mantener un clima de progreso, justicia y paz en Colombia;  fomenta el desarrollo humano,  la conciencia ambiental, el desarrollo sostenible  y la educación privada de calidad.
	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

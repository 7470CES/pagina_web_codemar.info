﻿
<ul class="nave">
		
		<li><a href="index.php">Inicio</a>
		
		<ul>
			
			<li><a href="qsomos.php">Nuestra Historia</a></li>
			
			<li> <a href="">Lo que nos proponemos</a>
			
			            <ul>
						
						<li><a href="mision.php">Misión</a></li>
				        <li><a href="vision.php">Visión</a></li>
						</ul>
			</li>
			
			
			
					<li><a href="npilares.php">Nuestros Pilares</a></li>
				<li><a href="nsimbolos.php">Nuestros Simbolos</a></li>
				<li><a href="nuniformes.php">Nuestros Uniformes</a></li>
				<li><a href="nperfil.php">Nuestro Perfil</a></li>
			
			
			
		
		
		      
			</ul>
			</li>
		
		
		
		
		
		
		
		
			<li><a href="nmodelo.html">Nuestro modelo pedagogico</a>
		
		<ul>
				  <li><a href="edufornuper.php">Educamos para formar una nueva persona</a></li>
				  <li><a href="educonstruir.php">Educamos para formar una nueva sociedad</a></li>
				  
			
			
			
			<li><a href="formaedu.php">Características de la Educación Marianista</a>
			
			
			        <ul>
			</li>
				<li><a href="formaenfe.php">Formación en la fe</a></li>
<li><a href="eduintedecali.php">Educación integral y de calidad</a></li>
<li><a href="espiritufam.php">Espíritu de familia</a></li>
<li><a href="edujusticiapaz.php">Educación para la justicia y la paz</a></li>
<li><a href="adaptacioncambio.php">Adaptación al cambio</a></li>

						
						</ul>
				<li><a href="sinstievalpro.php">Sistema Institucional de Evaluación y Promoción</a></li>
			</li>
					
		</ul>
			
			
			
			</li>
				
				
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<li><a href="">Niveles Ofrecidos</a>
			
			<ul>
			<li><a href="edupresco.php">Educación Pre-Escolar</a>
				<li><a href="edubasica.php">Educación Básica</a>
					<li><a href="edumedia.php">Educación Media Vocacional</a>
						<li><a href="proadmin.php">Proceso de Admisión</a>
			</ul>
			
			</li>
	    <li><a href="">Servicios Complementarios</a>
	
			<ul>
	         <li><a href="biblioteca.php">Biblioteca</a></li>
              <li><a href="tdirigidas.php">Tareas Dirigidas</a></li>
             <li><a href="cursosremediales.php">Cursos Remediales</a></li>
              <li><a href="cursospre-saic.php">Cursos Pre-Saber</a></li>
             <li><a href="edeportivo.php">Entrenamiento Deportivo</a></li>
             <li><a href="cafeteria.php">Cafetería</a></li>
             <li><a href="piscina.php">Piscina</a></li>
			</ul>

	
	
	
	
	</li>
	    <li><a href="">Vida Escolar</a>
	
	          <ul>
	         <li><a href="cordemaracadem.php">Cordemar Académico</a></li>
              <li><a href="cordemareco.php">Cordemar Ecológico</a></li>
             <li><a href="edeportivo.php">Cordemar Deportivo</a></li>
              <li><a href="cordemarcult.php">Cordemar Cultural</a></li>
				  <li><a href="cordemarecreativo.php">Cordemar Recreativo</a></li>
			</ul>
	
	</li>
	
	    <li><a href="ncomunidad.php">Nuestra Comunidad</a>
	
	
	
	<ul>
						
						<li><a href="cazul.php">Cordemar Azul</a></li>
				        <li><a href="cprofesores.php">Claustro de Profesores</a></li>
		                <li><a href="cacademico.php">Consejo Académico</a></li>
				        <li><a href="">Cordemar Estudiantil</a>
		
		                      <ul>
						
						<li><a href="cestudiantil.php">Consejo Estudiantil</a></li>
				        <li><a href="fraternidades.php">Fraternidades Escolares Cordemarianas</a></li>
						</ul>
		
		
		
		</li>
		                <li><a href="asociaciondepadresdf.php">Asociación de Padres</a></li>
				        <li><a href="asociaciondexyegresados.php">Asociación de Exalumnos y Egresados</a></li>
		                <li><a href="cmariana.php">Congregación mariana</a></li>
				        <li><a href="asociaciondefensora.php">Asociación Defensora de Animales y del Ambiente de Codazzi</a></li>
		       
						</ul>
	
	
	
	</li>
	    <li><a href="contacto.php">Contactenos</a></li>
        <li><a href="http://cordemar.org/documentos/" onclick="return confirm('Sera Dirigido Al Directorio De Documentos Compartidos De La Institución CORDEMAR');">Cartelera de Información</a></li>
		
		</ul>
		
<aside id="logo1"><a href="index.php"><img src="img/ESCUDO ACADEMICO CORDEMAR.png" width="150" height="150" alt=""/></a></aside>
			<article id="titulo1"><img src="img/banner.png" width="900" height="150" alt=""/></article>
			<aside id="logo2"><a href="index.php"><img src="img/maria.png" width="150" height="150"/></a></aside>
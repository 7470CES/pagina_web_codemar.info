// JavaScript Document

function validacion(){
	
    var nombres = document.getElementById("nombres").value;
	var apellidos = document.getElementById("apellidos").value;
	var asunto = document.getElementById("asunto").value;
	var email = document.getElementById("email").value;
	var mensaje = document.getElementById("mensaje").value;
	
if(nombres === ""){
	
	
	alert("Por Favor Dijite Los Nombres");
	
	return false;
}

	
	if(apellidos === "")	{
	
	
	alert("Por Favor Dijite Los Apellidos");
	
	return false;
    }
	
	
	if(asunto === "")	{
	
	
	alert("Por Favor Dijite el Asunto");
	
	return false;
    }
	
	if(email === "")	{
	
	
	alert("Por Favor Dijite El Email");
	
	return false;
    }
	
	if(mensaje === "")	{
	
	
	alert("Por Favor Dijite El Mensaje");
	
	return false;
}
	
}
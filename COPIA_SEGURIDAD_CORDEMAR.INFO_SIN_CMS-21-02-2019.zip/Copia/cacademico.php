﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CONSEJO ACADÉMICO</title>
	<link rel="stylesheet" href="css/estilosacademico.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/cacademico.png" width="500" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>CONSEJO ACADÉMICO</center></strong></h1>
			<p>&nbsp;</p>
		El Consejo Académico es la autoridad académica de el Colegio El Corazón de María, CORDEMAR; y   está integrado por:
<p>&nbsp;</p>
•	El Rector, quien lo preside y lo convoca.<p>&nbsp;</p>
•	Un profesor de cada área, que sea Miembro Activo de la Corporación.<p>&nbsp;</p>
•	Un profesor de cada nivel de enseñanza (pre-escolar, básica y Media Vocacional) que sea Miembro Activo de la Corporación.
<p>&nbsp;</p>
Son funciones del Consejo Académico, las siguientes:
<p>&nbsp;</p>
•	Conceptuar ante la Junta Directiva, sobre la creación, modificación o supresión de unidades académicas y cursos.<p>&nbsp;</p>
•	Revisar y adoptar los programas académicos a tenor de las normas legales vigentes.<p>&nbsp;</p>
•	Decidir sobre las medidas disciplinarias que deban aplicarse a los estudiantes y que según los reglamentos sean de su competencia.<p>&nbsp;</p>
•	Proponer a la Junta Directiva la concesión de Títulos, Distinciones honoríficas y Distinciones académicas.<p>&nbsp;</p>
•	Decidir sobre los asuntos académicos que estatutariamente no sean de competencia de otros funcionarios.<p>&nbsp;</p>
•	Estudiar la creación de programas académicos y ajustarlos a los requerimientos legales, emitiendo el concepto de viabilidad a la Dirección General.<p>&nbsp;</p>
•	Determinar la promoción, aplazamiento o reprobación de estudiantes, cada final de año lectivo.<p>&nbsp;</p>
•	Estudiar la viabilidad de crear cursos remediales, cursos nivelatorios y cursos de refuerzo académico.  Planear y formular el contenido y metodología apropiada.<p>&nbsp;</p>
•	Las demás que le sean asignadas por la Junta Directiva y por los Reglamentos.


	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

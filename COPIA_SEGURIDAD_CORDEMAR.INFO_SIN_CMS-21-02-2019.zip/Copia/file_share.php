﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">
<title>Contactenos</title>
     <link rel="stylesheet" href="css/estilosf.css">
     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">
	 <link rel="stylesheet" href="css/font-awesome.css">

	<script src="js/jquery-3.1.0.min.js"></script>
	<script src="js/main.js"></script>
	<script language="javascript" src="js/validacion.js"></script>
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section id="seccion1">		
	  <article id="form">
		  <hr style="color: white"/>
				<p><h2><strong>DOCUMENTOS DE INTERES PUBLICO</p></h2></strong>
			<hr style="color: white"/>
		<br>
		<ul class="lista">
		  <li><a href="http://www.cordemar.org/img/matriculas.jpg"><img src="img/file-viewer-08-535x535.png" width="20" height="20" alt="" title="Presione"/>&nbsp;Matriculas Abiertas</a></li>
		  
		  </ul>
		</article>
   </section>
		
		<hr style="color: white"/>
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

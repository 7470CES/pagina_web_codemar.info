﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">
<title>NOTICE#5</title>
     <link rel="stylesheet" href="css/estilosnotice.css">
     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">
	 <link rel="stylesheet" href="css/font-awesome.css">

	<script src="js/jquery-3.1.0.min.js"></script>
	<script src="js/main.js"></script>
	<script language="javascript" src="js/validacion.js"></script>
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section id="seccion1">		
	  <article id="leftnotice">
		<hr style="color: white"/>
		  <p><strong>¿ESTAMOS CRIANDO UNA GENERACIÓN DE INÚTILES? ¿ESTAMOS CRIANDO VAGOS?  ¿EN QUÉ ESTAMOS FALLANDO?

		  <hr style="color: white"/></strong></p>
		  <p>&nbsp;</p>
		  
		  <div id="img"><img src="img/Noticia 201801_6.png" alt="" style="float:left; width:393px; height:400px"/></div>
	    Por: Iván Soto	
Enero 17 de 2018.
		   <p>&nbsp;</p>
LA NUEVA GENERACIÓN
		   <p>&nbsp;</p>
Hay que llamarlos varias veces en la mañana para que vayan al Colegio. 
Se levantan irritados, pues se acuestan muy tarde hablando por teléfono, viendo tele o conectados a la Internet. No se ocupan de que su ropa esté limpia y mucho menos ponen un dedo en nada que tenga que ver con 'arreglar algo en el hogar'.
		   <p>&nbsp;</p>
Idolatran a sus amigos y viven poniéndoles 'defectos' a sus padres, a los cuales acusan a diario de “sus traumas”. No hay quien les hable de ideologías, de moral y de buenas costumbres, pues consideran que ya lo saben todo. Hay que darles su 'semana' o propina, de la que se quejan a diario porque -'eso no me alcanza'-. Si son universitarios, siempre inventan unos paseos de fin de semana que lo menos que uno sospecha es que regresarán con un embarazo, cayéndose de borrachos o habiendo fumado droga.
Definitivamente estamos rendidos y la tasa de retorno se aleja cada vez más, pues aún el día en que consiguen un trabajo hay que seguir manteniéndolos. Me refiero a un segmento cada vez mayor de los chicos de clases medias urbanas que bien pudieran estar entre los 16 y los 24 años y que conforman a la ya tristemente célebre Generación de los NINI’S, que ni estudian ni trabajan, ó estudian y trabajan con todo el pesar.
		   <p>&nbsp;</p>
¿EN QUÉ ESTAMOS FALLANDO?
Para los nacidos en los cuarenta y cincuenta, el orgullo reiterado era que se levantaban de madrugada a ordeñar las vacas con el abuelo; que tenían que limpiar la casa; que lustraban sus zapatos; algunos fueron limpiabotas y repartidores de diarios; otros llevaban al taller de costura la ropa que elaboraba nuestra madre o tenían un pequeño salario en la iglesia en donde ayudaban a oficiar la misa cada madrugada.
		   <p>&nbsp;</p>
Lo que le pasó a nuestra generación es que nosotros mismos “elaboramos un discurso” que no dio resultado: '¡YO NO QUIERO QUE MI HIJO PASE LOS TRABAJOS QUE YO PASÉ!'. Usted por qué tiene lo que tiene…? Pues porque le costó su esfuerzo… muchos sacrificios, y así es que aprendimos a valorar los esfuerzos de nuestros padres al ”ver y compartir” su esfuerzo, en lugar de “ocultarlo” y aparentar que todo es “color de rosa” en la vida. Sin embargo, NOSOTROS ACOSTUMBRAMOS A NUESTROS HIJOS A RECIBIR TODO POR OBLIGACIÓN.
		   <p>&nbsp;</p>
Nuestros hijos nunca han conocido la escasez en su exacta dimensión, se criaron desperdiciando...
El 'dame' y el 'cómprame' siempre son generosamente complacidos y ellos se han convertido en habitantes de una pensión con todo incluido, (TV, DVD, Equipo de sonido, Internet y comer en la cama, Recogerle el reguero que dejan porque siempre se les hace tarde para salir, etc…) y luego pretendemos que nuestra casa sea un hogar… o exigimos o preguntamos, por qué nuestros hijos se aíslan, no comparten con nosotros, ya que cualquier cosa es mejor que sus padres o una actividad familiar.
Quien les suministró todo eso a nuestros hijos…NOSOTROS MISMOS, SOLITOS Y SABIENDO QUE NO ESTABA BIEN. Al final se marchan a la conquista de una pareja y vuelven al hogar divorciados o porque la cosa 'les va mal' en su nueva vida.
		   <p>&nbsp;</p>
Los que tienen hijos pequeños, pónganlos los domingos a lavar los carros y a limpiar sus zapatos… a ganarse las cosas. Un pago simbólico por eso puede generar una relación en sus mentes entre trabajo y bienestar. Víktor Frankl dice que “LO QUE HACE FALTA ES EDUCAR EN EL AMOR AL TRABAJO (CREATIVO)”. La música de moda, los conciertos, la tele, la moda y toda la electrónica de la comunicación han creado un marco de referencia muy diferente al que nos tocó, y ellos se aprovechan de nuestra supuesta des-información para salirse con la suya; ya que ahora los ‘HIJOS MANDAN Y LOS PADRES OBEDECEN’, pues ahora somos padres ignorantes con hijos informados –mal- pero con información al cabo. Será cierto que:
“SOMOS LA GENERACIÓN QUE PEDÍA PERMISO A LOS PADRES; Y AHORA, PIDE PERMISO A LOS HIJOS...?”
Estamos forzados a revisar los resultados, si fuimos muy permisivos o si sencillamente hemos trabajado tanto, que el cuidado de nuestros hijos queda en manos de las domésticas maestros, y en un medio ambiente cada vez más deformante y supuestamente por nuestro cargo de conciencia de no tener mucho tiempo con ellos, subsanarlo con cosas materiales.
NUNCA ES TARDE PARA CAMBIAR COMPARTE ESTE ARTICULO SI ENTRE TU GENTE EXISTE ALGUIEN A QUIEN LE INTERESE ESTE TEMA







		  <hr style="color: white"/>
		
		</article>
</section>
		
		<hr style="color: white"/>
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

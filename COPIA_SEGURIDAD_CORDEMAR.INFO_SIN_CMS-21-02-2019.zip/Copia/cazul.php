﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CORDEMAR AZUL</title>
	<link rel="stylesheet" href="css/estilosacerca.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/corazul.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>CORDEMAR AZUL</center></strong>
			<p>&nbsp;</p>
			Se conoce con el nombre de Cordemar Azul,  al grupo de corporados;  es decir aquellas personas que han formalizado su vínculo con la institución,  haciéndose miembros de la Corporación Colegio El Corazón de María, CORDEMAR,  y asumiendo las responsabilidades que se derivan de tal dignidad.   Existen tres clases de miembros:   Beneméritos,  Activos y Benefactores.
<p>&nbsp;</p>
Están representados por su Junta Directiva,  y el Grupo de Beneméritos que cumple la función de Comité de Etica.
<p>&nbsp;</p>
La misión principal de Cordemar Azul,  es salvaguardar los principios fundacionales y defender la doctrina de la institución y el espíritu corporativo que la anima.   Por lo tanto tiene plena propiedad para dirimir conflictos y emitir las orientaciones generales del Proyecto Educativo Institucional.
<p>&nbsp;</p>
También se conoce con el nombre de Cordemar Azul,  al espíritu corporativo que anima a la institución, que a su vez exige pertenencia, lealtad y compromiso.



	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

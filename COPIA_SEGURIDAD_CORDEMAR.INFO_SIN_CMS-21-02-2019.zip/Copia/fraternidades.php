﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>FRATERNIDADES ESCOLARES CORDEMARIANAS</title>
	<link rel="stylesheet" href="css/estilosfraternidades.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/fracordemar.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>FRATERNIDADES ESCOLARES CORDEMARIANAS</center></strong></h1>
			<p>&nbsp;</p>
			El Sistema de Casas o Fraternidades, es un sistema colegiado que busca organizar las competiciones deportivas, académicas, y culturales dentro de la institución.
	<p>&nbsp;</p>
Las casas compiten por el título de Campeón participando en diferentes competencias a lo largo del año lectivo en distintas áreas:
	<p>&nbsp;</p>
Política:  Debate, cargos de gobierno escolar.  Las casas funcionan como partidos políticos escolares.
	<p>&nbsp;</p>
Academia:  Olimpiadas de Lectura. Matemáticas. Ciencias.  Puntaje en simulacros de Prueba SABER.    Y Pruebas SABER ICFES.
	<p>&nbsp;</p>
Deporte: Volleyball, Microfutbol.  
	<p>&nbsp;</p>
Juegos.  De mesa: Ajedrez, Damas, Monopolio, Cashflow.  De coordinación física por equipos: carrera, carrera con obstáculos, salto, salto en cuerda, aeróbicos.
	<p>&nbsp;</p>
Cultura:  Danza.  Baile urbano.  Poesía.  Teatro.  Canto.  Reinado. 
 	<p>&nbsp;</p>

En el Día del Idioma, en el Reinado Ecológico, en los juegos inter-casas, en comprensión lectora, en Ortografía y las Olimpiadas matemáticas, entre otras.

	<p>&nbsp;</p>
Cada alumno del colegio es asignado a una de las cuatro casas o fraternidades para que se haga miembro: 
Cordemar Alpha Phi
Cordemar Delta Shi
Cordemar Kappa Gamma
Cordemar Lambda Pi


	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

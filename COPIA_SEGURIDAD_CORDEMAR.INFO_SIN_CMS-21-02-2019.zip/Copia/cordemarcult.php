﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CORDEMAR CULTURAL</title>
	<link rel="stylesheet" href="css/estiloscordemaracadem.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/cordemar_recreativo.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>CORDEMAR CULTURAL</strong></h1>
			<p>&nbsp;</p>
	El Colegio preocupado por conservar los valores culturales 
no descuida, la promoción de las costumbres 
y prácticas folkloricas de nuestra región, 
reavivando en sus alumnos su sentido de pertenencia 
y su identificación con los valores culturales nacionales.
Por lo tanto incentiva el aprendizaje de aires y comparsas autóctonas en
el grupo de danza cordemariano.
Y también incentiva el arte dramático desde su grupo de teatro: Ágora Cultural.




		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Formación En La Fé</title>
	<link rel="stylesheet" href="css/estilosformafe.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<strong><center>Formación en la fe</center></strong>
			<p>&nbsp;</p>
			Educamos en la fe, a través de la acción pastoral promoviendo el diálogo entre la fe y la cultura.
<p>&nbsp;</p>
Evangelizar es anunciar la persona de Jesucristo y la buena noticia del Reino de Dios. La evangelización de los niños y jóvenes es la primera y principal finalidad de nuestra misión.
La tradición marianista destaca la importancia de la “fe del corazón”, aquella que se arraiga en lo más hondo de la persona e ilumina desde aquí toda la vida. Para encontrarse con Dios es necesario descender al fondo de uno mismo y saber exponerse al misterio que se encierra dentro de nosotros.
<p>&nbsp;</p>
Quien no encuentra a Dios en su interior, no lo encontrará en lugar alguno. Si, por el contrario, percibe ahí su presencia, lo podrá presentir en medio de la vida. Configurados por una cultura que nos arrastra siempre hacia lo exterior, hemos de desarrollar más nuestra “capacidad de interioridad”, es decir, la capacidad de interpretar y vivir la propia vida desde dentro.
<p>&nbsp;</p>
En la educación marianista formar en la fe supone:
<p>&nbsp;</p>
• Presentar explícitamente la persona de Jesús
• Provocar un contacto directo con la Palabra de Dios.<p>&nbsp;</p>
• Enseñar a interpretar la realidad personal y social desde claves evangélicas.<p>&nbsp;</p>
• Educar en valores y actitudes que desarrollen la disponibilidad a la fe y la apertura a Dios.<p>&nbsp;</p>
• Educar la interioridad.<p>&nbsp;</p>
			<p>&nbsp;</p>
• Ayudar a plantearse interrogantes sobre el sentido de la propia existencia.<p>&nbsp;</p>
• Ofrecer la Enseñanza Religiosa Escolar como una formación sistemática sobre el hecho religioso y el acontecimiento cristiano.<p>&nbsp;</p>
• Ofrecer propuestas de acompañamiento personal en el proceso de maduración vocacional.<p>&nbsp;</p>
• Promover grupos y comunidades que ayuden a vivir como creyentes y discípulos de Jesús en el mundo de hoy.
			<p>&nbsp;</p>
• Proponer momentos de celebración y oración.<p>&nbsp;</p>
• Favorecer vivencias positivas de pertenencia eclesial.<p>&nbsp;</p>
• Acceder progresivamente a experiencias de compromiso por el Reino de Dios.<p>&nbsp;</p>
• Preparar en fin, a nuestros alumnos para que puedan llegar a una adhesión personal, libre y explícita de la fe cristiana en la Iglesia.<p>&nbsp;</p>
<p>&nbsp;</p>
Estamos convencidos de que el Evangelio de Jesucristo tiene fuerza salvadora para dar un sentido nuevo a nuestra vida.
<p>&nbsp;</p>


La fe no es un elemento desencarnado. Se expresa siempre a través de unas categorías culturales y, al mismo tiempo, transforma esa cultura que le sirve de vehículo de expresión. La cultura y la fe no son dos realidades opuestas.
<p>&nbsp;</p>
En nuestro colegio promovemos, por lo tanto, un diálogo entre esta cultura de la que formamos parte y la fe en su expresión más radical: la vida y el misterio de Jesucristo. La acción educativa promueve en ellos un proceso que les conduce a realizar una síntesis de fe y cultura.    Los sentidos y significados que aportan ambas realidades pueden consolidar un proyecto personal integrado y coherente. Optamos por un modelo de cultura y de ciencia no cerrado en sí mismo, sino abierto a la trascendencia.
<p>&nbsp;</p>
Este diálogo entre la cultura y la fe se plantea en dos direcciones:
<p>&nbsp;</p>
• La inculturación de la fe nos exige aprender de la cultura de nuestro tiempo, descubriendo en ella signos de vida y esperanza, aceptando todos sus elementos humanizadores e integrándolos en el mensaje cristiano.
• La evangelización de la cultura. Este diálogo conlleva también descubrir la fragilidad de esa misma cultura, ejercer una función crítica capaz de cuestionar aquellos contravalores que deshumanizan la sociedad y proponer alternativas de transformación de nuestro mundo desde las actitudes del Evangelio.
<p>&nbsp;</p>
La fe en diálogo con la cultura apunta a una manera nueva de ser, de mirar, de comprender y tratar la realidad, de considerar a las personas, los acontecimientos y las cosas. Es decir, el diálogo entre la fe y la cultura tiende en definitiva a realizar en nuestros alumnos una integración de la fe en la vida.



		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Nuestra Historia</title>
	<link rel="stylesheet" href="css/estiloshistory.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/historia.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>NUESTRA HISTORIA</center></strong></h1>
			<p>&nbsp;</p>
			El colegio fue fundado en 1969, 
por las Profesoras Mercedes Salgado Martínez, y
Rosita Del Castillo Sanabria,
con el propósito de proporcionar una educación integral de calidad,
que se caracterizara por su efectividad,  
a niños de familias de clase media  interesadas 
en tener hijos aplomados, 
que reconocieran lo valioso que poseían, 
se prepararan para conservarlo 
y que posteriormente en su vida adulta, 
con su comportamiento inteligente, lo acrecentaran.
<p>&nbsp;</p>
Desde entonces es un compromiso fundamental 
que el alumno pacta con sus padres y profesores,  
educarse y formarse como persona de bien, 
para continuar sus estudios superiores y trabajar, 
en empleos o negocios productivos, 
siéndole útil a su familia y a la sociedad circundante, 
escalando posiciones sociales y económicas, 
que recompensen el esfuerzo realizado, 
y la inversión hecha por sus padres en su educación. 
<p>&nbsp;</p>
El alumno cordemariano tiene el deber 
de llegar a ser más de lo que hoy es, 
y llegar a tener más de lo que hoy tiene.
A prepararse para servir…
Y a no negociar jamás 
su sagrado derecho de progresar y ser feliz.

	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>El Espíritu de familia</title>
	<link rel="stylesheet" href="css/estilosespiritufam.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<strong><center>El Espíritu de familia</center></strong>
			<p>&nbsp;</p>
			Nuestras relaciones se viven en un espíritu de familia.   Todas las personas, especialmente en los primeros años de nuestra vida, necesitamos entornos afectivos cálidos y estables. La familia es quien mejor puede aportar este ambiente.
<p>&nbsp;</p>
El espíritu de familia es un estilo de vida con rasgos específicos, reconocibles en nuestros colegios.
Ofreciendo un clima de aceptación y acogida, el colegio actúa como una “segunda familia”, favoreciendo la madurez y el crecimiento.
<p>&nbsp;</p>
El colegio es un lugar donde se vive un clima familiar en el que todos, alumnos, profesores y personal no docente, podamos sentirnos “como en casa”. Por ello:
<p>&nbsp;</p>
• Buscamos tratar a nuestros alumnos con respeto y cercanía. La autoridad del educador se basa
en la profesionalidad y en la entrega; no la entendemos como una forma de poder, sino como
una oportunidad de servir a la persona del alumno.<p>&nbsp;</p>

• Promovemos la familiaridad y el trato cordial en nuestros centros. Vivimos la acogida y la apertura a nuestro entorno como un valor de nuestra tradición educativa.<p>&nbsp;</p>

• Creamos vínculos y dinámicas compartidas entre familias y escuela para trabajar juntos en la
misma dirección.<p>&nbsp;</p>

• Impulsamos la comunicación y colaboración entre nuestros colegios.<p>&nbsp;</p>

• Fomentamos el sentido de pertenencia a la familia marianista extendida por el mundo.<p>&nbsp;</p>


Creemos que la diversidad enriquece<p>&nbsp;</p>

Vivimos en un mundo en el que las fronteras son muy tenues, en un mosaico de realidades íntimamente relacionadas: diversidad de culturas, de creencias y de procedencias. Nuestro proyecto educativo debe promover este encuentro con lo diferente e impulsar la fraternidad.<p>&nbsp;</p>

Creemos que todas las personas tienen un tesoro que aportar y que la diversidad, lejos de ser un problema, es un regalo para toda institución educativa.   Entendemos que educar desde y para la diversidad, significa trabajar por una cultura de paz y de encuentro.   <p>&nbsp;</p>


“Para educar a los niños hay que vivir con ellos. Un colegio nunca será una casa de educación
sino a condición de ser una segunda familia”.     (J. P. Lalanne SM)




		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

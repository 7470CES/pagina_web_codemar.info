﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CURSOS REMEDIALES</title>
	<link rel="stylesheet" href="css/estiloshistory.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<h1><strong><center>CURSOS REMEDIALES</center></strong></h1>
			<p>&nbsp;</p>
			Son cursos diseñados para “remediar” falencias, insuficiencias, deficiencias, “baches de conocimiento” que pueda presentar uno o varios alumnos de uno o varios grados, en una o varias asignaturas o áreas curriculares.    Su propósito principal es re-explicar lo que el alumno ya debió haber aprendido en grados anteriores y lograr el desarrollo tardío de esa destreza o habilidad que aún no posee en dichas asignaturas o áreas.
<p>&nbsp;</p>
Por lo general se realizan en tiempo complementario y exigen un esfuerzo adicional por el incremento de actividad escolar extra,  a la normalmente establecida para un grado.   Es decir el alumno debe dedicar un tiempo adicional,  un esfuerzo adicional,  para revisar, estudiar y practicar temas que no están en la programación de las asignaturas de su grado.  También implica la realización de tareas “adicionales” que afianzan dichos temas y desarrollan tales habilidades.
<p>&nbsp;</p>
Hay un tiempo específico para llevar a cabo estos “cursos remediales”,  son cuidadosamente planeados por el profesor que regenta la asignatura,  teniendo en cuenta los diagnósticos realizados en clase,  están dirigidos exclusivamente a los alumnos que presentan el mismo caso de falencia o estancamiento en su progreso;  y deben ser autorizados por Rectoría,  para desarrollarse en el tiempo indicado, por el Consejo Académico.

	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

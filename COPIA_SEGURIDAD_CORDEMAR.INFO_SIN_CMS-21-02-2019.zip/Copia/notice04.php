﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">
<title>NOTICE#4</title>
     <link rel="stylesheet" href="css/estilosnotice.css">
     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">
	 <link rel="stylesheet" href="css/font-awesome.css">

	<script src="js/jquery-3.1.0.min.js"></script>
	<script src="js/main.js"></script>
	<script language="javascript" src="js/validacion.js"></script>
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section id="seccion1">		
	  <article id="leftnotice">
		<hr style="color: white"/>
		  <p><strong>RESULTADOS DE LOS DEBATES CORDEMARIANOS DE DICIEMBRE 2018

		  <hr style="color: white"/></strong></p>
		  <p>&nbsp;</p>
		  <div id="img"><img src="img/Noticia 201801_5.png" alt="" style="float:left; width:393px; height:400px"/></div>
	    Por: William Andrés Rodríguez Acevedo <p>&nbsp;</p>

El pasado 12 de Diciembre, día de la Virgen de Guadalupe, como es tradicional ya, se dio inicio a la serie de debates cordemarianos de fin de año.   En esta oportunidad fueron ocho temas, a saber:
 <p>&nbsp;</p>
Tema 1:
“De la Cátedra de identidad Cordemariana”.(Positiva) Lengerke Diaz, López Moscote Vs (Negativa) Teheran Ramírez, Ortega Garcés
 <p>&nbsp;</p>
Tema 2:
“La Fraternidad Cordemariana como valuarte y propósito misional”.(Positiva) Lengerke Diaz, Ramírez Ortega Vs (Negativa) Teheran Ramírez, Vence Amazán
 <p>&nbsp;</p>
Tema 3:
“La Formación en Matemáticas y la exigencia académica para asegurarla”.(Positiva) Diaz Herrera, Jiménez Sierra Vs (Negativa) Sosa Alvarez, Hinojosa García
 <p>&nbsp;</p>
Tema 4: 
“La Obligatoriedad para el alumno de bajo rendimiento de participar en las actividades de refuerzo y el curso remedial”(Positiva) Iguarán García, Saavedra Sandoval Vs (Negativa) Barrios Martínez, Fuentes Barrios
 <p>&nbsp;</p>
Tema 5:
“Animadores juveniles marianistas y la dirección de las fraternidades escolares”.(Positiva) Cotes Villarreal, Villarreal Vides Vs (Negativa) Villa Castro, Castellanos Mejía
 <p>&nbsp;</p>
Tema 6:
“La actividad ambiental cordemariana y su resurgir en el marco de los 50 Años”(Positiva) Sierra Carvajalino, Montoya Henao Vs (Negativa) Ruiz Novoa, Fragozo Benavides
 <p>&nbsp;</p>
Tema 7:
“La necesidad de incluir la doctrina disciplinaria cordemariana en la vida escolar de los profesores cordemarianos. ¿Qué tan cordemarianos son los profesores de hoy?”(Positiva) Núñez Alarcón, Daza Daza Vs (Negativa) Molina Galvis, Mena Rodríguez 
 <p>&nbsp;</p>
Tema 8:
“Avances de la cultura corporativa cordemariana, la consolidación de nuestros valores compartidos y el código de honor cordemariano”(Positiva) Gil Oñate, García Henao Vs (Negativa) Barranco Yanes,  Garzón Rojas
 <p>&nbsp;</p>
Los resultados se dieron así: <p>&nbsp;</p>

Tema 1.   Positiva: 7 votos,   Negativa: 6 votos.  Imponiéndose: Lengerke – López.</br>

Tema 2.   Positiva: 8 votos, Negativa: 5 votos. Imponiéndose: Lengerke – Ramírez.</br>

Tema 3.   Positiva: 6 votos, Negativa: 7 votos. Imponiéndose: Sosa – Hinojosa.</br>

Tema 4.   Positiva: 10 votos, Negativa: 3 votos. Imponiéndose: Iguarán - Saavedra.</br>

Tema 5.   Positiva: 8 votos, Negativa: 5 votos.  Imponiéndose: Cotes – Villarreal.</br>

Tema 6.   Positiva: 7 votos, Negativa: 6 votos.  Imponiéndose: Sierra – Montoya.</br>

Tema 7.   Positiva: 8 votos, Negativa: 5 votos. Imponiéndose: Nuñez – Daza.</br>

Tema 8.   Positiva: 7 votos, Negativa: 6 votos.  Imponiéndose: Gil – García.</br>

<p>&nbsp;</p>
Las conclusiones, están siendo incluidas en los planes anuales institucionales, y en modificaciones que deben ser incluidas en el Proyecto Educativo Cordemariano. <p>&nbsp;</p>

Trataremos de ellas en un informe posterior.</br>






		  <hr style="color: white"/>
		
		</article>
</section>
		
		<hr style="color: white"/>
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Nuestros Uniformes</title>
	<link rel="stylesheet" href="css/estilosnsimbolos.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/uniformes.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>NUESTROS UNIFORMES</center></strong>
			<p>&nbsp;</p>
			El uniforme es un traje de presentación, debe ser impecable, y debe presentarse tal  y como se estipuló en la institución.  El alumno no podrá hacer uso del uniforme para otras actividades distintas a las escolares.
<p>&nbsp;</p>

Las insignias y los uniformes del colegio, hacen parte de la imagen institucional, por tanto, el alumno debe portar tales accesorios y atuendos con responsabilidad y honor.   Es responsabilidad del Padre o acudiente no regalar, ni entregar a terceros ninguno de los uniformes de uso privativo de los miembros de la institución.
<p>&nbsp;</p>

El uniforme de diario para las niñas es el siguiente:
			<p>&nbsp;</p>

•	Jardinera  de tela escocesa azul, según modelo establecido.<br>

•	Blusa blanca del modelo estipulado.<br>

•	Medias blancas.<br>

•	Zapatos colegiales mafalda de color rojo.<br>

•	Correa roja.<br>

<p>&nbsp;</p>
El uniforme de diario de los varones es el siguiente:
			<p>&nbsp;</p>

•	Camiseta azul con el escudo académico bordado.<br>

•	Pantalón azul turquí de tela de lino o de drill.<br>

•	Zapatos colegiales azules correctamente lustrados.<br>

•	Correa negra.<br>
<p>&nbsp;</p>

El uniforme de educación física  es el siguiente: 
			<p>&nbsp;</p>

•	Una sudadera azul con vivos blancos, del diseño estipulado y que en la camiseta contiene el escudo académico bordado y en el pantalón el logotipo institucional estampado en alto relieve.<br>

•	Pantalonetas (varones) o short (niñas) en color azul rey del diseño estipulado.<br>

•	Medias blancas.<br>

•	Zapatos tenis totalmente blancos. <br>








	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>EDUCACIÓN PRE-ESCOLAR</title>
	<link rel="stylesheet" href="css/estiloshistory.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/preescolar.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>EDUCACIÓN PRE-ESCOLAR</strong></h1>
			<p>&nbsp;</p>
		 El departamento de Educación Parvularia del Colegio El Corazón de María cuenta con los Niveles de Jardín  y Transición    (Pre Kínder y Kínder Garden).
<p>&nbsp;</p>
Tiene la misión de llevar a cabo los principios pedagógicos de bienestar, actividad, singularidad, potenciación, relación, unidad, significado y juego, para ello se basa en los programas pedagógicos del MEN teniendo como referente nuestro Proyecto Educativo; y los valores cordemarianos. 
<p>&nbsp;</p>
Lo primordial es generar contextos de aprendizajes significativos y contextualizados para los párvulos, valorando las características propias de su edad, que los motiven a través de actividades educativas que desarrollen todas sus capacidades, utilizando variados recursos para prepararlos para su acceso a la enseñanza escolar.

	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

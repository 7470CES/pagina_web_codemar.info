﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Nuestro Perfil</title>
	<link rel="stylesheet" href="css/estilosnperfil.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><div id="img"><img src="img/m.png" width="250" height="350" alt=""/></div></article>
		<article id="right">
			<strong><center>NUESTRO PERFIL</center></strong>
			<p>&nbsp;</p>
			El Colegio El Corazón de María, CORDEMAR,  funciona de acuerdo a parámetros estrictos, que garantizan eficiencia en los procesos, y permanencia de los principios fijados desde su fundación.
			<p>&nbsp;</p>
   
“Alumnos capaces, puntuales, ordenados, responsables, atentos y dispuestos, practicantes de una sana disciplina escolar, que desarrolla en ellos habilidades y competencias propias de un alfabetismo universal, que los faculta para interactuar con éxito en el competitivo mundo de hoy”.

<p>&nbsp;</p>
El Egresado del colegio “El Corazón de María” de Codazzi, debe poseer las siguientes características:
			<p>&nbsp;</p>

•	Posee una línea moral que lo identifica.  Es cristiano.
			<p>&nbsp;</p>


•	Posee valores morales, intelectuales, sociales, y del trabajo acordes con el camino del bien y con su época.<p>&nbsp;</p>


•	Es autónomo e independiente, con un criterio definido, una personalidad propia e individual.
			<p>&nbsp;</p>


•	Socialmente adaptado.  Útil a su comunidad, es un factor de progreso social.
			<p>&nbsp;</p>


•	Respetuoso de los derechos y honra de los demás.
			<p>&nbsp;</p>


•	Tolerante, siempre inclinado a crear y a mantener un clima de armonía, progreso y paz.<br>

•	Defensor de la vida en todas sus manifestaciones.
			<p>&nbsp;</p>


•	Defensor de los ambientes sanos y los ecosistemas naturales.
			<p>&nbsp;</p>


•	Posee facultades de trabajo disciplinado y productivo.
			<p>&nbsp;</p>


•	Es capaz de trabajar en equipo, tomar decisiones y solucionar problemas en grupo.<br>

•	Comunicador eficiente, sabe expresar lo que piensa en forma correcta, tanto oral como escrita.
			<p>&nbsp;</p>


•	Está fundamentado, con una información social, económica, y política adecuada, con conceptos claros y herramientas teóricas suficientes para, de acuerdo a su nivel, analizar la realidad circundante.<p>&nbsp;</p>


•	Está acostumbrado a la acción de analizar y discernir multiplicidad de hechos y situaciones en la vida diaria.<p>&nbsp;</p>


•	Es consciente de su realidad, de sus limitaciones, y  potencialidades, sus oportunidades y sus capacidades.<p>&nbsp;</p>


•	Es creativo, capaz de ingeniar, y generar ideas nuevas y útiles.<p>&nbsp;</p>


•	Posee la habilidad de actualizarse, desaprender y aprender continuamente, y seguir su construcción intelectual y personal.<p>&nbsp;</p>


•	Es sincero en sus afectos y equilibrado en la forma de expresar sus sentimientos.<p>&nbsp;</p>


•	Intenta conocerse a sí mismo y comprender a los demás.<p>&nbsp;</p>


•	Entiende la importancia de las relaciones estables con su pareja, que le permitan crecer y mejorar como persona.  Conoce los riesgos de practicar relaciones sexuales en forma irresponsable.<p>&nbsp;</p>


•	Se esfuerza por mantener sentimientos de gratitud y lealtad hacia su colegio.<p>&nbsp;</p>


•	Es vigoroso, físicamente saludable.<p>&nbsp;</p>


•	Es moderado en sus hábitos alimenticios y conocedor de la ventaja que ofrece la comida fresca y bien balanceada.<p>&nbsp;</p>


•	Es cuidadoso en el uso de sustancias tóxicas para el consumo humano (alcohol, drogas alucinógenas, y alcaloides, etc)  Conoce los estragos físicos que causan.<p>&nbsp;</p>


•	Es estricto en la práctica de sus hábitos de higiene y cuidado personal.  Es pulcro en su presentación, y cuida su imagen ante los demás con esmero.   <br> 



	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

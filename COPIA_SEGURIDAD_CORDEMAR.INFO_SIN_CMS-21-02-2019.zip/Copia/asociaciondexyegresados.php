﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ASOCIACIÓN DE EXALUMNOS Y EGRESADOS</title>
	<link rel="stylesheet" href="css/estiloshistory.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<h1><strong><center>ASOCIACIÓN DE EXALUMNOS Y EGRESADOS</center></strong></h1>
			<p>&nbsp;</p>
		La Asociación de Egresados del Colegio El Corazón de María, está conformada por todos aquellos alumnos que se han graduado de bachilleres en la institución.
			<p>&nbsp;</p>
			Formalizan su ingreso el día de su graduación.    Están suscritos entre los corporados,  dada su condición son miembros de Cordemar Azul con régimen especial.
<p>&nbsp;</p>
Los exalumnos son personas que han estudiado en el Colegio El Corazón de María,  pero por algún motivo han tenido que continuar sus estudios en otra institución y no pudieron graduarse de bachilleres en CORDEMAR.      Cuando desean pertenecer a esta Asociación, entonces se vinculan formalizando su membresía.

	    </article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

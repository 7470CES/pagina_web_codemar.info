﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ASOCIACIÓN DEFENSORA DE ANIMALES Y DEL AMBIENTE DE CODAZZI</title>
	<link rel="stylesheet" href="css/estilosasodefensores.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<h1><strong><center>ASOCIACIÓN DEFENSORA DE ANIMALES Y DEL AMBIENTE DE CODAZZI</center></strong></h1>
			<p>&nbsp;</p>
		En un principio (1992)  fue un programa piloto (una prueba que se decidió hacer para demostrar que sí podíamos hablar de ecología y especialmente del buen trato hacia los animales en la sociedad local, caracterizada por la crueldad hacia ellos.  Dueños de mascotas, carniceros, conductores de carros de mula, etc.),     hasta que fue formalizada en 1995.     A partir de ahí es el programa ecológico del Colegio El Corazón de María, CORDEMAR.
	<p>&nbsp;</p>
Es en la Asociación Defensora de Animales y del Ambiente, en la que nuestros alumnos de Media Vocacional realizan las horas de trabajo social obligatorias.   Y en la que desarrollamos nuestro Proyecto Ambiental Escolar,  que es transversal a todos los cursos y fraternidades escolares.
	<p>&nbsp;</p>
“Creemos que si fomentamos en nuestros niños y jóvenes, el aprecio y el respeto por la vida en todas sus formas, a la vuelta de unos años, tendremos adultos sensibles, compasivos, responsables de sus actos, y comprometidos con mantener un clima de armonía, progreso y paz en nuestro país, y que no tolerarán la violencia.
	<p>&nbsp;</p>
Le dejamos muy claro a los niños que no debe existir ningún ideal político o social, que justifique quitar la libertad, el bienestar y la vida de otros; la destrucción y la barbarie  no es la forma de construir una mejor sociedad.   Sabemos que la violencia se aprende, y que la insensibilidad es la salvaguardia de la violencia.  La compasión es algo que debemos enseñar y predicar con el ejemplo”.
	<p>&nbsp;</p>
Es en esta actividad ambiental, en la que nuestros niños aprenden a sentir compasión por el que sufre,  y a ser solidario con quien necesita ayuda.   Valores cristianos que se pueden aplicar con las demás personas,  con los animales, y con la creación entera.  (Encíclica Laudato sí del Papa Francisco).




	    </article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Educamos para el compromiso</title>
	<link rel="stylesheet" href="css/estilosespiritufam.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<strong><center>Educamos para el compromiso</center></strong>
			<p>&nbsp;</p>
			Millones de personas viven hoy una existencia degradada, impropia de su dignidad como seres humanos.  En muchos lugares del mundo encontramos una humanidad rota por las desigualdades sociales, la pobreza, la guerra y la violencia, la intolerancia y el deterioro del medio ambiente natural.
<p>&nbsp;</p>
El espíritu misionero propio de nuestro carisma marianista,  nos lleva a dar prioridad al servicio a los más necesitados y a impulsar una cultura de la solidaridad.   Educar en la escuela de hoy es enseñar a los niños y jóvenes,   “que sólo  llegamos de verdad a ser humanos cuando  trabajamos por la plenitud de la vida”.       Un colegio que anuncia la Buena Noticia de Jesús escucha también la llamada del Evangelio que nos impulsa a la construcción de un mundo más justo, solidario y pacífico.
<p>&nbsp;</p>
Educar en el colegio para el compromiso con la justicia y la paz supone:
<p>&nbsp;</p>
•	Ayudar a que nuestros alumnos tomen conciencia de las causas de la pobreza, las desigualdades sociales, el sufrimiento humano y los desequilibrios medioambientales y se comprometan en favor de una humanidad mejor.    Ver críticamente nuestro mundo es el primer paso hacia una acción solidaria.<p>&nbsp;</p>
•	Favorecer los procesos de adquisición de hábitos y actitudes de servicio, solidaridad, tolerancia, no violencia, civismo y ayuda desinteresada.<p>&nbsp;</p>
•	Estimular la creación de grupos de voluntariado en favor de los más necesitados.<p>&nbsp;</p>
•	Cultivar en los jóvenes la convicción de que sus acciones pueden cambiar el mundo.<p>&nbsp;</p>
•	Vivir, asimismo, nuestro compromiso a favor de la dignidad humana y de una sociedad más solidaria, estableciendo en nuestros colegios estructuras internas adecuadas y justas.<p>&nbsp;</p>


La solidaridad, entendida seriamente, no es un “tema del programa”, ni una “actividad”, ni un “sentimiento compasivo”, ni siquiera una “materia transversal”.   Es una manera global de situarse ante la vida, ante los demás seres humanos y ante el planeta mismo.


		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>EDUCACIÓN BÁSICA</title>
	<link rel="stylesheet" href="css/estiloshistory.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/edubasica.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>EDUCACIÓN BÁSICA</strong></h1>
			<p>&nbsp;</p>
		La Enseñanza Básica del Colegio El Corazón de María,  está formada por los cursos de primero a noveno.
<p>&nbsp;</p>
Tiene como principal misión que todos los niños y niñas logren los objetivos de aprendizaje propuestos en el currículo nacional vigente, a través del uso de metodologías adecuadas y una serie de actividades complementarias.
<p>&nbsp;</p>
Conjuntamente con esto nos preocupamos por la formación en la fe, propiciando diversas experiencias concretas de crecimiento integral.
<p>&nbsp;</p>
Así, a través del paso por los diferentes niveles nuestros alumnos y alumnas van aprendiendo a desarrollar diversas destrezas, focalizados siempre en los valores cordemarianos, logrando una formación integral que les permita niveles de autonomía para el mejor ingreso a la educación media.


	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">
<title>NOTICE#1</title>
     <link rel="stylesheet" href="css/estilosnotice.css">
     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">
	 <link rel="stylesheet" href="css/font-awesome.css">

	<script src="js/jquery-3.1.0.min.js"></script>
	<script src="js/main.js"></script>
	<script language="javascript" src="js/validacion.js"></script>
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section id="seccion1">		
	  <article id="leftnotice">
		<hr style="color: white"/>
		  <p><strong>COLEGIO “EL CORAZÓN DE MARÍA”: COLEGIATURA DEL 2019…  MATRÍCULAS ABIERTAS!...
		  <hr style="color: white"/></strong></p>
		  <p>&nbsp;</p>
		  
		  <div id="img"><img src="img/Noticia 201801_1.jpg" alt="" style="float:left; width:393px; height: 400px"/></div> Se inicia la temporada de matrículas para la colegiatura del 2019, en el Colegio “El Corazón de María” de Agustín Codazzi. </br>

<strong>Los horarios de atención son: </strong><p>&nbsp;</p> 

1.	En la mañana, de 9:00 AM  a  12:00 M</br>
2.	En la tarde, de 4:00 PM a 6:00 PM.</br>
<p>&nbsp;</p> 

<strong>Los requisitos de matrícula son:</strong><p>&nbsp;</p> 

1.	Carpeta plastificada con celuguía de color azul.</br>
2.	Registro civil del alumno</br>
3.	Fotocopia de la tarjeta de identidad del alumno</br>
4.	Fotocopia de los dos lados, del padre de familia o acudiente</br>
5.	Certificado médico</br>
6.	Fotocopia del carné de la EPS</br>
7.	Certificados de estudio de los grados cursados de 5º en adelante</br>
8.	Ficha de Matrícula diligenciada</br>
9.	Formulario de membresía diligenciado</br>
10.	Presentarse el acudiente con el alumno en el momento de la matrícula.</br>
		  <p>&nbsp;</p> 
 <p>&nbsp;</p> 
<p>&nbsp;</p> 
<p>&nbsp;</p> 
<strong>Portafolio de Servicios:</strong><p>&nbsp;</p> 

1.	Pre-escolar:  KINDERGARDEN CORDEMAR KIDS:  Jardín B,  Transición.</br>
2.	Primaria:  CORDEMAR KIDS: 1º, 2º, 3º, 4º, 5º.</br>
3.	Bachillerato: CORDEMAR TEENAGERS: 6º, 7º, 8º, 9º, 10º, 11º.</br>

<p>&nbsp;</p> 

<strong>Características del Servicio:</strong><p>&nbsp;</p> 

1.	Programas académicos SM actualizados a 2019</br>
2.	Clases regentadas por profesores calificados</br>
3.	Metodología pedagógica marianista SM</br>
4.	Grupos de máximo 12 estudiantes</br>
5.	Actividades de Afianzamiento y Refuerzo Académico</br>
6.	Pastoral educativa marianista SM</br>
7.	Tareas dirigidas</br>
8.	Cursos remediales</br>
9.	Ejercicios de motricidad fina</br>
10.	Piscina escolar: Ejercicios de motricidad gruesa</br>
11.	Acuaterapia de aprendizaje</br>


		  <hr style="color: white"/>
		
		</article>
</section>
		
		<hr style="color: white"/>
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

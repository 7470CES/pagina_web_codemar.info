﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">
<title>NOTICE#3</title>
     <link rel="stylesheet" href="css/estilosnotice.css">
     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">
	 <link rel="stylesheet" href="css/font-awesome.css">

	<script src="js/jquery-3.1.0.min.js"></script>
	<script src="js/main.js"></script>
	<script language="javascript" src="js/validacion.js"></script>
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section id="seccion1">		
	  <article id="leftnotice">
		<hr style="color: white"/>
		  <p><strong>COMUNICADO DEL CLAUSTRO DE PROFESORES A LOS PADRES DE ALUMNOS DE BAJO RENDIMIENTO

		  <hr style="color: white"/></strong></p>
		  <p>&nbsp;</p>
		  
	     Señores Padres de Familia:

Les recordamos el objetivo principal, de los alumnos en el colegio:  Aprender conocimientos, desarrollar habilidades y competencias para resolver problemas en la vida diaria.
		  <p>&nbsp;</p>

Para esto es, que ustedes nos encomiendan a sus hijos.  Para que los instruyamos y los eduquemos, desarrollando en ellos valores, habilidades y competencias.  De las que dispondrán ellos mismos en su Proyecto de Vida.   Para que al ejecutarlo sean por fin,  íntegros, independientes, y autónomos.   Rindan y se realicen en la sociedad.
 <p>&nbsp;</p>
Esto no puede lograrse de otra manera, que haciendo trabajo académico.  Es nuestro deber como profesores, exigir a nuestros alumnos trabajo académico y es deber de ustedes como padres, exigir evidencias de dicho trabajo.
<p>&nbsp;</p>
Para obtener los objetivos académicos, se debe cumplir con una secuencia de acciones escolares previamente establecidas en cada materia.  “El alumno debe realizar el esfuerzo”.   Y lo debe realizar en términos de igualdad.  El alumno que es promovido necesariamente tiene que realizar el esfuerzo mínimo aceptable.  Que consiste en llevar un cuaderno de apuntes al día y ordenado; haber realizado el número de tareas programadas para la asignatura en el año.  Y haber obtenido el puntaje mínimo requerido al computar el acumulado académico con el puntaje del último periodo.
<p>&nbsp;</p>
No queremos ver más aquí, alumnos, que esperan alcanzar los objetivos sin esfuerzo aparente.  Quieren ganar de milagro, sin hacer el trabajo.  Recuérdenles que sin esfuerzo no hay logro.    Todo cuesta esfuerzo.   Es la condición principal de estar vivos.   Es una condición humana, desde el comienzo de la humanidad.    Como aprende alguien a hacer arroz, o a cocinar, o a organizar una casa, o un oficio cualquiera, o hacer negocios?   Poniendo atención a las indicaciones, practicando, esforzándose por hacer bien lo que hace mal, y por hacer mejor lo que ya hace bien.    No hay otra forma.  Ustedes conocen otra?
<p>&nbsp;</p>
Ustedes nos encomiendan sus hijos para que los enseñemos, no para que les sirvamos de guardería.   No para que sirvamos de niñeras, sino de profesores que imparten conocimientos, desarrollan competencias y los habilitan para resolver problemas.    Esa es nuestra tarea, y la cumplimos.   A pesar de que haya alumnos que no les guste, y aún no entiendan la razón por la cual,  deben aprender a valerse solos.   Lograr independencia y buen juicio.  Tener un comportamiento inteligente, colocarse metas y esforzarse para lograrlas. 
<p>&nbsp;</p>
Ustedes y nosotros debemos trabajar en equipo, para concienciar a los alumnos, y exigirles que aprendan.  Ningún padre desea lo peor para sus hijos,  pero hace muy mal aquel, que lo enseña a no hacer nada, y lo vuelve improductivo.  Porque le duele exigirle rendimiento y responsabilidad.     Piensen ustedes, que hará sin sus padres?  Estará en capacidad de valerse por sí mismo y abrirse camino en la vida?...  simplemente no...  porque no está dispuesto a trabajar, ni a esforzarse por nada.  Ese es el peor castigo del papá que siempre le hace los trabajos a los hijos.  No encuentra en ellos un apoyo en la vejez.
<p>&nbsp;</p>
El objetivo aquí no son notas, ni boletines sin asignaturas valoradas en “Bajo”.  Es evidenciar en el alumno, cada día, un comportamiento más inteligente, más juicioso, más maduro.  En casa deben exigirle cada día más habilidad y competencia.  Más responsabilidad en sus trabajos. Más independencia y autonomía en sus decisiones.    Y de todo eso hay evidencia.  Exijan evidencias de progreso académico.
<p>&nbsp;</p>
Para que un alumno apruebe una asignatura en el colegio “El Corazón de María”, es necesario que muestre las evidencias de que estuvo aquí haciendo trabajo académico con nosotros durante el año lectivo.




		  <hr style="color: white"/>
		
		</article>
</section>
		
		<hr style="color: white"/>
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

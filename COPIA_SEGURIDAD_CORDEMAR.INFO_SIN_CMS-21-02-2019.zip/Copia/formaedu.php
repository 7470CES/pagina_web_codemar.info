﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CON UNA FORMA DE EDUCAR: LAS CARACTERÍSTICAS DE LA EDUCACIÓN MARIANISTA</title>
	<link rel="stylesheet" href="css/estilosformaedu.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<strong><center>CON UNA FORMA DE EDUCAR: LAS CARACTERÍSTICAS DE LA EDUCACIÓN MARIANISTA</center></strong>
			<p>&nbsp;</p>
			La pedagogía marianista es realización práctica de una filosofía y una espiritualidad vividas y sentidas. Los marianistas recibimos, del fundador Guillermo José Chaminade, un carisma, una espiritualidad, un estilo de vida y pensamiento para transmitirlo a los demás con el estilo y
las formas del mundo de hoy.
<p>&nbsp;</p>
La tradición marianista sobre enseñanza ha destacado unos rasgos característicos de esta forma de educar. Estos rasgos se han enriquecido y actualizado a través de la acción pedagógica de muchos educadores a lo largo de casi doscientos años. Son las características de la educación marianista:
<p>&nbsp;</p>
•	Formación en la fe y educación de la Conciencia<p>&nbsp;</p>
•	Educación integral y de calidad<p>&nbsp;</p>
•	Espíritu de familia<p>&nbsp;</p>
•	Educación para el servicio, la justicia y la paz<p>&nbsp;</p>
•	Adaptación al cambio tecnológico, económico y social<p>&nbsp;</p>
<p>&nbsp;</p>
Así,  es María de Nazaret quien nos da ejemplo de escucha, acogida y cercanía.  Fue la primera educadora de Jesús y de ella aprendemos un estilo de educar.





		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

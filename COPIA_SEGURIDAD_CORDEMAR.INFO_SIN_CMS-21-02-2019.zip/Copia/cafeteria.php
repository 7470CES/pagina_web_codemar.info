﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Cafeteria</title>
	<link rel="stylesheet" href="css/estilosedeportivo.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/logo.png" width="350" height="350" alt=""/></article>
		<article id="right">
			<h1><strong><center>CAFETERÍA</cente></center></strong></h1>
			<p>&nbsp;</p>
			Los alumnos en su recreo pueden hacer uso de la cafetería o tienda escolar,  para merendar, encontrar algún refresco, y aliviar la fatiga ocasionada por la rutina de trabajo escolar diario.


		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

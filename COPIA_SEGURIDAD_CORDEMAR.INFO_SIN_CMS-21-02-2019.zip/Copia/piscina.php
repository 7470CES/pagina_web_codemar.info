﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Píscina</title>
	<link rel="stylesheet" href="css/estilosacerca.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section>		
	  <article id="left"><img src="img/piscina.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>PISCINA</center></strong>
			<p>&nbsp;</p>
			Los alumnos asisten por lo menos dos horas por semana a la piscina, a realizar en ella, actividades de acuaterapia de aprendizaje, y ejercicios de motricidad gruesa, coordinación, destreza, confianza y seguridad en sí mismos.    Deben ingresar en compañía del instructor(a), y de su asistente.   Deben cumplir en todo momento con el reglamento, el uso de su traje de baño reglamentario, gorro, y demás elementos;  y abstenerse de comer alimentos en el área de la piscina.
	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>EDUCACIÓN MEDIA</title>
	<link rel="stylesheet" href="css/estiloshistory.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/edumedia.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>EDUCACIÓN MEDIA</strong></h1>
			<p>&nbsp;</p>
		Constituye la culminación, consolidación y avance en el logro de los niveles anteriores y comprende dos grados, el décimo y el undécimo. Tiene como fin la comprensión de ideas y los valores universales y la preparación para el ingreso del educando a la educación superior y al trabajo. (Ley 115. Art. 27).<p>&nbsp;</p>
La educación media académica permite al estudiante, según sus intereses y capacidades, profundizar en un campo específico de las ciencias, las artes o las humanidades y acceder a la educación superior. (Ley 115. Art. 29).<p>&nbsp;</p>

Desde la perspectiva de una educación integral y de un currículum evangelizador, enfocado e incremental, el ciclo de educación media del Colegio El Corazón de María,  implementa sus acciones y actividades educativas con la mirada en la calidad educativa y el propósito de formar hombres y mujeres de bien, que funcionen plenamente como agentes económicos y políticos en la sociedad;   que estén dispuestos a contribuir para alcanzar y mantener un clima de armonía y paz en nuestro país.   <p>&nbsp;</p>Que valoren la importancia de la Dignidad Humana,  las libertades individuales, los Derechos civiles y la conservación e integridad de la creación (Cuidado y protección de la Naturaleza).






	
		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">
<title>Contactenos</title>
     <link rel="stylesheet" href="css/estilosf.css">
     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">
	 <link rel="stylesheet" href="css/font-awesome.css">

	<script src="js/jquery-3.1.0.min.js"></script>
	<script src="js/main.js"></script>
	<script language="javascript" src="js/validacion.js"></script>
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
			
		</nav>
	<section id="seccion1">		
	  <article id="form">
		<form class="contact_form" method="post" action="enviar.php" onSubmit="return validacion();">
		<ul>
			
			<li>
			<label for="website">Nombres</label>
            <input type="text" name="nombres" id="nombres" />
			
			
			</li>
			<li>
			<label for="website">Apellidos</label>
            <input type="text" name="apellidos" id="apellidos" />
			
			
			</li>
			<li>
			<label for="website">Asunto</label>
            <select name="asunto" id="asunto">
		   <option value="Preguntas">Solicitud de Documentos</option>
		  <option value="Preguntas">Solicitud de Verificación</option>
		 <option value="Preguntas">Preguntas, Sugerencias y Quejas</option>
		  <option value="Preguntas">Solicitud De Cupos</option>
			  </select>
			
			
			</li>
			<li>
			<label for="website">Email</label>
            <input type="email" name="email"  id="email"/>
			
			
			</li>
		  <li>
			<label for="website">Mensaje</label>
            <textarea type="text" name="mensaje"  id="mensaje" rows="10" cols="32"></textarea>
			
			
			</li>
			<li>
    <button class="submit" type="submit">Enviar</button>
			</ul>
</form>
		</article>
</section>
		
		<hr style="color: white"/>
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

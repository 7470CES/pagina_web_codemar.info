﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">
<title>NOTICE#2</title>
     <link rel="stylesheet" href="css/estilosnotice.css">
     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">
	 <link rel="stylesheet" href="css/font-awesome.css">

	<script src="js/jquery-3.1.0.min.js"></script>
	<script src="js/main.js"></script>
	<script language="javascript" src="js/validacion.js"></script>
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section id="seccion1">		
	  <article id="leftnotice">
		<hr style="color: white"/>
		  <p><strong>PROCEDIMIENTO PARA REALIZAR ACTIVIDADES DE NIVELACIÓN
CORRESPONDIENTES AL AÑO LECTIVO 2018

		  <hr style="color: white"/></strong></p>
		  <p>&nbsp;</p>
		  
	     1.	Verifique su nombre en el listado de alumnos aplazados. (Si su nombre no aparece, es porque o ha sido promovido al Grado siguiente o definitivamente ha sido reprobado)

  <p>&nbsp;</p>
2.	Verifique las asignaturas que debe nivelar. (Máximo Ocho. Puede ser que aparezcan porque su promedio general en dichas asignaturas no alcanzó al mínimo aceptable 3.0 o porque por inasistencia del alumno le faltan calificaciones y no se ha podido obtener el resultado final)

  <p>&nbsp;</p>
3.	. Encuentre en fotocopiadora el trabajo o trabajos de la asignatura o asignaturas que debe nivelar y llévelo para realizarlo en casa. (Los profesores tienen hasta el día Viernes 1 de Febrero para dejar el trabajo)

  <p>&nbsp;</p>
4.	Haga el trabajo académico estipulado. Tómese su tiempo para hacerlo bien, y estúdielo. Preparándose a conciencia para la evaluación de nivelación. (Recuerde que para alcanzar la valoración de Aprobado, se computa la calificación del trabajo académico con la calificación de la evaluación; el promedio debe ser igual o superior a 3.0, que equivale al 60% mínimo exigido o más, no menos)

  <p>&nbsp;</p>
5.	Verifique el día y hora del examen de nivelación de cada asignatura.  
  <p>&nbsp;</p>
6.	El día de presentar su examen.  Preséntese con 15 minutos de antelación.  Cancele en Secretaría el valor de la Nivelación           $16.500 Pesos.
  <p>&nbsp;</p>
7.	Entregue el trabajo en Secretaría, reclame su recibo de pago, y desplácese hasta el salón donde presentará la evaluación.
  <p>&nbsp;</p>
8.	Haga la evaluación, conteste a conciencia y sin premura.  Entregue su evaluación para que la califiquen.
  <p>&nbsp;</p>
9.	El día Viernes de la Semana siguiente, verifique su calificación.  (Fin del procedimiento)

  <p>&nbsp;</p>
<strong>Nota:</strong> Si desea acompañamiento institucional en el proceso para nivelar sus asignaturas, entonces en compañía del padre de familia acérquese a Rectoría para que le autoricen realizar su nivelación durante el primer periodo académico, bajo la dirección del profesor que regente dicha asignatura.  


Gracias por su atención.



		  <hr style="color: white"/>
		
		</article>
</section>
		
		<hr style="color: white"/>
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

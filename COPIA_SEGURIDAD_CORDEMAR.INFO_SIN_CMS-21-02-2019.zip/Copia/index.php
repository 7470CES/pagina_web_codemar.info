﻿<!doctype html>

<html>

<head>

<meta charset="utf-8">

	<meta name="Description" content="El Colegio El Corazón de María,  es una comunidad educativa católica inspirada en el Carisma Marianista.  Brinda, a la luz de la espiritualidad y pedagogía marianistas, una educación integral de calidad con un currículo centrado en la persona,  con metodologías y recursos adecuados.  Al estilo de María, evangeliza para formar personas integras, éticas y proactivas, que se comprometan con la defensa de la vida, la justicia, la paz y la creación. Y, crea vínculos interpersonales e institucionales que manifiestan el modelo mariano de Iglesia que responde a los nuevos retos de la sociedad.">

<title>Colegio El Corazón De María</title>

     <link rel="stylesheet" href="css/estilos.css">

     <link href="fonts/Open Sans Condensed.css" rel="stylesheet">

	 <link rel="stylesheet" href="css/estilos.css">

	 <link rel="stylesheet" href="css/font-awesome.css">



	<script src="js/jquery-3.1.0.min.js"></script>

	<script src="js/main.js"></script>

	

</head>



<body>


	<div id="contenedor">

		

		<header>

			

			<?php include('header.php');?>

		</header>

				

	<nav>

			<?php include('nav.php');?>

		</nav>

	<section>		

	  <article id="left">

		<ul id="sliderr" class="slider">

		    <li><img src="img/img1.jpg" width="1200px;" height="400px"></li>

			<li><img src="img/img2.jpg" width="1200px;" height="400px"></li>

			<li><img src="img/img3.jpg" width="1200px;" height="400px"></li>

                        <li><img src="img/img4.jpg" width="1200px;" height="400px"></li>

			<li><img src="img/img5.jpg" width="1200px;" height="400px"></li>

			<li><img src="img/img6.jpg" width="1200px;" height="400px"></li>

                        <li><img src="img/img7.jpg" width="1200px;" height="400px"></li>

                        <li><img src="img/img8.jpg" width="1200px;" height="400px"></li>

			

		  

		  </ul>

		</article>

</section>

		<div id="seccion2">

		  <article id="noticias">

			  

				<hr style="color: white"/>

				<p><h2><strong>MATRICULAS ABIERTAS</p></h2></strong>

			<hr style="color: white"/>

			<p>&nbsp;</p>

			<div id="img"><img src="img/Noticia 201801_1.jpg" width="193" height="200" alt=""/></div>

			

			Se inicia la temporada de matrículas para la colegiatura del 2019, en el Colegio “El Corazón de María” de Agustín Codazzi. </br>  

	<p>&nbsp;</p>

Los horarios de atención son:  

	<p>&nbsp;</p>

1.	En la mañana, de 9:00 AM  a  12:00 M </br>

2.	En la tarde, de 4:00 PM a 6:00 PM.</br>



			<p>&nbsp;</p>

			<div class="ver"><a href="notice01.php">&nbsp;&nbsp;Ver Noticia</a></div>

		  </article>

			<article  id="news">

<hr style="color: white"/>

				<div class="noticias parpadea"><p><h2><strong><center>NOTICIAS</p></h2></strong></center></div>

			<hr style="color: white"/>





<ul class="newss">

	<li><a href="notice01.php">MATRÍCULAS ABIERTAS!..</a></li>

	<hr style="color: white"/>

		<li><a href="notice02.php">PROCEDIMIENTO PARA REALIZAR ACTIVIDADES DE NIVELACIÓN

CORRESPONDIENTES AL AÑO LECTIVO 2018

</a></li>

	<hr style="color: white"/>

		<li><a href="notice03.php">COMUNICADO DEL CLAUSTRO DE PROFESORES A LOS PADRES DE ALUMNOS DE BAJO RENDIMIENTO</a></li>

	<hr style="color: white"/>

		<li><a href="notice04.php">RESULTADOS DE LOS DEBATES CORDEMARIANOS DE DICIEMBRE 2018</a></li>

	<hr style="color: white"/>

		<li><a href="notice05.php">¿ ESTAMOS CRIANDO UNA GENERACIÓN DE INÚTILES? ¿ESTAMOS CRIANDO VAGOS?  ¿EN QUÉ ESTAMOS FALLANDO?</a></li>

	<hr style="color: white"/>

		<li><a href="notice06.php">¿ QUE PASARÁ CON LAS ACTIVIDADES DE LA JORNADA DE LA TARDE ?</a></li>

		</ul>

</article>

			</section>





		<div id="seccion3">

			<article id="links">

				<hr style="color: white"/>

				<p><h2><strong>OTROS LINKS</p></h2></strong>

			</article>

			<hr style="color: white"/>

	<article id="linex1"><a href="http://www.clm-mlc.org/Latin_America_esp.html"><img src="img/escudo.jpg" width="200" height="180" alt=""/></a></article>

			

	<article id="linex2"><a href="https://www.facebook.com/groups/108310262575544/"><img src="img/grup.jpg" width="200" height="180" alt=""/></a></article>

			

	<article id="linex3"><a href=""><img src="img/comunidades.png" width="200" height="180" alt=""/></a></article>

	

	<article id="linex4"><a href="http://www.ediciones-sm.com.co/"><img src="img/logosm.jpg" width="200" height="180" alt=""/></a></article>

	

	<article id="linex5"><a href="http://marianistas.org/portada/"><img src="img/agora.jpg" width="200" height="180" alt=""/></a></article>

	

	<article id="linex6"><a href="http://webmail.cordemar.org"><img src="img/correo.png" width="200" height="180" alt="correo"/></a></article>	

	</section>

		<hr style="color: white"/>

		<footer><?php include('footer.php');?>

			</footer>

</body>

</html>


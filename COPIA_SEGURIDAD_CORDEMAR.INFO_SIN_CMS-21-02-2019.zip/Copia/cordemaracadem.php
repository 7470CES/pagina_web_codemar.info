﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CORDEMAR ACADÉMICO</title>
	<link rel="stylesheet" href="css/estiloscordemaracadem.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/vida_escolar.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<h1><strong><center>CORDEMAR ACADÉMICO</strong></h1>
			<p>&nbsp;</p>
	El CORDEMAR, funciona de acuerdo a parámetros estrictos, 
que garantizan eficiencia en los procesos, 
y permanencia de los principios fijados desde su fundación.
   <p>&nbsp;</p>
Alumnos capaces, puntuales, ordenados, 
responsables, atentos y dispuestos, 
practicantes de una sana disciplina escolar, 
que desarrolla en ellos habilidades y competencias 
propias de un alfabetismo universal, 
que los faculta para interactuar con éxito 
en el competitivo mundo de hoy.
<p>&nbsp;</p>
El alumno del colegio 
recibe una sólida formación académica, 
con un marcado énfasis 
en procesos económicos y políticos, 
que lo habilitan para ser competitivo, 
sin embargo esa formación académica 
se complementa con un fuerte componente axiológico 
que determina la escala de valores que rige su comportamiento 
y garantiza que su inteligencia y habilidades 
estén siempre, al servicio del bien.
   <p>&nbsp;</p>
Nuestros alumnos son promesa de futuro para la República de Colombia 
y para la sociedad que pertenecen, 
porque reciben una formación integral de alta calidad 
que garantiza su disposición a mantener 
un clima de progreso y paz 
en cualquier lugar que se desempeñen.
<p>&nbsp;</p>
Mas que un alumno competitivo
Buscamos la cualificación de un ser humano
La formación de una persona de bien.  De un cristiano.
Que pueda desempeñarse en las distintas áreas que desee
Y desenvolverse con propiedad en la sociedad.
Siguiendo normas de cortesía, elegancia, y distinción,
Que le faciliten las relaciones con las demás personas 
y el logro de sus objetivos sociales y económicos.

		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>

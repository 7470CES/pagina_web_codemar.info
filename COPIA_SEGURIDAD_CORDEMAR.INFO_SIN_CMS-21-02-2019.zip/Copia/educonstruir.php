﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Educamos Para Construir Una Sociedad Nueva</title>
	<link rel="stylesheet" href="css/estilosedufornuper.css">
<link href="fonts/Open Sans Condensed.css" rel="stylesheet">
</head>

<body>
	<div id="contenedor">
		
		<header>
			
			<?php include('header.php');?>
		</header>
				
	<nav>
			<?php include('nav.php');?>
		</nav>
	<section>		
	  <article id="left"><img src="img/npersonas.png" width="400" height="400" alt=""/></article>
		<article id="right">
			<strong><center>EDUCAMOS PARA CONSTRUIR UNA SOCIEDAD NUEVA</center></strong>
			<p>&nbsp;</p>
			Cuando miramos el mundo surgen en nosotros numerosas incertidumbres sobre lo que nos deparará la vida en el futuro. Pero, al menos, de algo podemos estar seguros: si queremos que la Tierra pueda ser un hogar digno y feliz para todas las personas que la habitan, la sociedad humana deberá transformarse.
<p>&nbsp;</p>
Debemos, por tanto, trabajar para construir un futuro viable. La democracia, la equidad y la justicia social, la solidaridad con los más débiles, la tolerancia entre diferentes, la paz, la responsabilidad ciudadana y el cuidado de nuestro entorno natural deben ser valores clave de este mundo en devenir. Debemos asegurarnos de que la sostenibilidad sea esencial en nuestra manera de vivir, de dirigir nuestras naciones y comunidades y de interactuar a nivel global.
<p>&nbsp;</p>
En esta evolución hacia los cambios fundamentales de nuestro estilo de vida y nuestros comportamientos, la educación –en su sentido más amplio– juega un papel preponderante. La educación es la fuerza del futuro, porque ella constituye uno de los instrumentos más poderosos para realizar este cambio.
<p>&nbsp;</p>

“Para colaborar con el proyecto de Jesús sobre la humanidad queremos formar sociedades solidarias, inclusivas, democráticas, interculturales, relacionándonos desde nuestra dignidad de personas y responsabilizándonos en el cuidado de la vida”.



		</article>
		</section>
		<hr style="color: white" />
		<footer><?php include('footer.php');?>
			</footer>
</body>
</html>
